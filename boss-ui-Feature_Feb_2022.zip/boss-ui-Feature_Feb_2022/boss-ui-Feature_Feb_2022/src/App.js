import React from "react";
import "App.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import RegionHome from "pages/region/RegionHome";
import Home2 from "pages/home/Home2";
import OnHoldReport from "pages/reports/onhold/OnHoldReport";
import { AsnReport } from "pages/reports/asnsummary/AsnReport";
import { AsnDetailReport } from "pages/reports/asndetail/AsnDetailReport";
import SingleSignOn from "components/SingleSignOn/SingleSignOn";
import Login from "components/Login/Login";
import { PoDetailReport } from "pages/reports/podetail/PoDetailReport";
import { PoSummaryReport } from "pages/reports/posummary/PoSummaryReport";
import { VoiDelayHistoryReport } from "pages/reports/voidelayhistory/VoiDelayHistoryReport";
import { VwoStatusHistoryReport } from "pages/reports/vwostatushistory/VwoStatusHistoryReport";
import { BulkReportOrderReport } from "pages/reports/bulkreportorder/BulkReportOrderReport";
import { VendorWorkOrderReport } from "pages/reports/vendorworkorder/VendorWorkOrderReport";
import { ThreePlInboundReport } from "pages/reports/threeplinbound/ThreePlInboundReport";
import { ThreePlOutboundReport } from "pages/reports/threeploutbound/ThreePlOutboundReport";
import { OppFailedOrderDetailsReport } from "pages/reports/oppfailedorderdetails/OppFailedOrderDetailsReport";
import { BusinessErrorPageReport } from "pages/reports/businesserror/BusinessErrorPageReport";
import { PreAsnNackReport } from "pages/reports/preasnnack/PreAsnNackReport";
import { SystemErrorReport } from "pages/reports/systemerror/SystemErrorReport";
import { TcErrorDetailReport } from "pages/reports/tcerrordetailpage/TcErrorDetailReport";
import { VendorPoNackReport } from "pages/reports/vendorpurchaseordernack/VendorPoNackReport";
import { AsBuiltNackReport } from "pages/reports/asbuiltnack/AsBuiltNackReport";
import { AsnNackReport } from "pages/reports/asnnack/AsnNackReport";
import { SnNackReport } from "pages/reports/snnack/SnNackReport";
import { SpNackReport } from "pages/reports/spnack/SpNackReport";
import { SnSummaryReport } from "pages/reports/shipnoticesummary/SnSummaryReport";
import {AdminReport} from "pages/admin/AdminReport";
import { SnHoldReport } from "pages/reports/snholdlog/SnHoldReport";

function App() {
  return (
    <>
      <div className="container">
         {/* <SingleSignOn /> */}
        <Router>
          <Switch>
            {/* <Route exact path="/login" component={Login} /> */}
            <Route exact path="/" component={RegionHome} />
            <Route exact path="/emea" component={Home2} />
            <Route exact path="/dao" component={Home2} />
            <Route exact path="/apj" component={Home2} />
            <Route path="/dao/reports" exact component={OnHoldReport} />
            <Route path="/emea/reports" exact component={OnHoldReport} />
            <Route path="/apj/reports" exact component={OnHoldReport} />

            <Route path="/dao/configuration" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui01.aus.amer.dell.com/BOSSPortal_DAO_SIT1/ContentPages/Configuration/StockRoomMapping.aspx";
                return null;
              }
            } />
             <Route path="/dao/support" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui01.aus.amer.dell.com/BOSSPortal_DAO_SIT1/ContentPages/Support/NewMessageLog.aspx";
                return null;
              }
            } />

<Route path="/dao/rules" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui01.aus.amer.dell.com/BOSSPortal_DAO_SIT1/ContentPages/Configuration/RulesConfigurationSearch.aspx";
                return null;
              }
            } />

<Route path="/emea/configuration" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui02.aus.amer.dell.com/BOSSPortal_EMEA_SIT29/ContentPages/Configuration/StockRoomMapping.aspx";
                return null;
              }
            } />

<Route path="/emea/support" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui02.aus.amer.dell.com/BOSSPortal_EMEA_SIT29/ContentPages/Support/NewMessageLog.aspx";
                return null;
              }
            } />

<Route path="/emea/rules" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui02.aus.amer.dell.com/BOSSPortal_EMEA_SIT29/ContentPages/Configuration/RulesConfigurationSearch.aspx";
                return null;
              }
            } />

<Route path="/apj/configuration" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui02.aus.amer.dell.com/BOSSPortal_APJ_SIT20/ContentPages/Configuration/StockRoomMapping.aspx";
                return null;
              }
            } />

<Route path="/apj/support" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui02.aus.amer.dell.com/BOSSPortal_APJ_SIT20/ContentPages/Configuration/RulesConfigurationSearch.aspx";
                return null;
              }
            } />

<Route path="/apj/rules" exact component={
              ()=>{
                window.location.href="https://bosnwge2ui02.aus.amer.dell.com/BOSSPortal_APJ_SIT20/ContentPages/Support/NewMessageLog.aspx";
                return null;
              }
            } />

            <Route
              path="/dao/reports/asn-summary"
              exact
              component={AsnReport}
            />
            <Route
              path="/emea/reports/asn-summary"
              exact
              component={AsnReport}
            />
            <Route
              path="/apj/reports/asn-summary"
              exact
              component={AsnReport}
            />
            <Route path="/dao/reports/onhold" exact component={OnHoldReport} />
            <Route path="/emea/reports/onhold" exact component={OnHoldReport} />
            <Route path="/apj/reports/onhold" exact component={OnHoldReport} />
            <Route
              path="/dao/reports/asn-detail"
              exact
              component={AsnDetailReport}
            />
            <Route
              path="/emea/reports/asn-detail"
              exact
              component={AsnDetailReport}
            />
            <Route
              path="/apj/reports/asn-detail"
              exact
              component={AsnDetailReport}
            />
            <Route
              path="/dao/reports/po-detail"
              exact
              component={PoDetailReport}
            />
            <Route
              path="/emea/reports/po-detail"
              exact
              component={PoDetailReport}
            />
            <Route
              path="/apj/reports/po-detail"
              exact
              component={PoDetailReport}
            />
            <Route
              path="/apj/reports/po-summary"
              exact
              component={PoSummaryReport}
            />
            <Route
              path="/dao/reports/po-summary"
              exact
              component={PoSummaryReport}
            />
            <Route
              path="/emea/reports/po-summary"
              exact
              component={PoSummaryReport}
            />
            <Route
              path="/apj/reports/voidelayhistory"
              exact
              component={VoiDelayHistoryReport}
            />
            <Route
              path="/dao/reports/voidelayhistory"
              exact
              component={VoiDelayHistoryReport}
            />
            <Route
              path="/emea/reports/voidelayhistory"
              exact
              component={VoiDelayHistoryReport}
            />

            <Route
              path="/apj/reports/3plinbound"
              exact
              component={ThreePlInboundReport}
            />
            <Route
              path="/dao/reports/3plinbound"
              exact
              component={ThreePlInboundReport}
            />
            <Route
              path="/emea/reports/3plinbound"
              exact
              component={ThreePlInboundReport}
            />
            <Route
              path="/apj/reports/3ploutbound"
              exact
              component={ThreePlOutboundReport}
            />
            <Route
              path="/dao/reports/3ploutbound"
              exact
              component={ThreePlOutboundReport}
            />
            <Route
              path="/emea/reports/3ploutbound"
              exact
              component={ThreePlOutboundReport}
            />
            <Route
              path="/apj/reports/vendorworkorder"
              exact
              component={VendorWorkOrderReport}
            />
            <Route
              path="/dao/reports/vendorworkorder"
              exact
              component={VendorWorkOrderReport}
            />
            <Route
              path="/emea/reports/vendorworkorder"
              exact
              component={VendorWorkOrderReport}
            />
            <Route
              path="/apj/reports/oppfailedorderdetailsreports"
              exact
              component={OppFailedOrderDetailsReport}
            />
            <Route
              path="/dao/reports/oppfailedorderdetailsreports"
              exact
              component={OppFailedOrderDetailsReport}
            />
            <Route
              path="/emea/reports/oppfailedorderdetailsreports"
              exact
              component={OppFailedOrderDetailsReport}
            />

             <Route
              path="/apj/reports/vwostatushistory"
              exact
              component={VwoStatusHistoryReport}
            />
            <Route
              path="/dao/reports/vwostatushistory"
              exact
              component={VwoStatusHistoryReport}
            />
            <Route
              path="/emea/reports/vwostatushistory"
              exact
              component={VwoStatusHistoryReport}
            />
            <Route
              path="/apj/reports/bulkreportorder"
              exact
              component={BulkReportOrderReport}
            />
            <Route
              path="/dao/reports/bulkreportorder"
              exact
              component={BulkReportOrderReport}
            />
            <Route
              path="/emea/reports/bulkreportorder"
              exact
              component={BulkReportOrderReport}
            />
             <Route
              path="/apj/reports/businesserrorpage"
              exact
              component={BusinessErrorPageReport}
            />
            <Route
              path="/dao/reports/businesserrorpage"
              exact
              component={BusinessErrorPageReport}
            />
            <Route
              path="/emea/reports/businesserrorpage"
              exact
              component={BusinessErrorPageReport}
            />
           <Route
              path="/apj/reports/preasnnack"
              exact
              component={PreAsnNackReport}
            />
            <Route
              path="/dao/reports/preasnnack"
              exact
              component={PreAsnNackReport}
            />
            <Route
              path="/emea/reports/preasnnack"
              exact
              component={PreAsnNackReport}
            />

            <Route
              path="/apj/reports/systemerror"
              exact
              component={SystemErrorReport}
            />
            <Route
              path="/dao/reports/systemerror"
              exact
              component={SystemErrorReport}
            />
            <Route
              path="/emea/reports/systemerror"
              exact
              component={SystemErrorReport}
            />


            <Route
              path="/apj/reports/tcerrordetail"
              exact
              component={TcErrorDetailReport}
            />
            <Route
              path="/dao/reports/tcerrordetail"
              exact
              component={TcErrorDetailReport}
            />
            <Route
              path="/emea/reports/tcerrordetail"
              exact
              component={TcErrorDetailReport}
            />

            <Route
              path="/apj/reports/vendorponack"
              exact
              component={VendorPoNackReport}
            />
            <Route
              path="/dao/reports/vendorponack"
              exact
              component={VendorPoNackReport}
            />
            <Route
              path="/emea/reports/vendorponack"
              exact
              component={VendorPoNackReport}
            />

            <Route
              path="/apj/reports/asbuiltnack"
              exact
              component={AsBuiltNackReport}
            />
            <Route
              path="/dao/reports/asbuiltnack"
              exact
              component={AsBuiltNackReport}
            />
            <Route
              path="/emea/reports/asbuiltnack"
              exact
              component={AsBuiltNackReport}
            />

            
            <Route
              path="/apj/reports/asnnack"
              exact
              component={AsnNackReport}
            />
            <Route
              path="/dao/reports/asnnack"
              exact
              component={AsnNackReport}
            />
            <Route
              path="/emea/reports/asnnack"
              exact
              component={AsnNackReport}
            />

              <Route
              path="/apj/reports/snnack"
              exact
              component={SnNackReport}
            />
            <Route
              path="/dao/reports/snnack"
              exact
              component={SnNackReport}
            />
            <Route
              path="/emea/reports/snnack"
              exact
              component={SnNackReport}
            />

            <Route
              path="/apj/reports/spnack"
              exact
              component={SpNackReport}
            />
            <Route
              path="/dao/reports/spnack"
              exact
              component={SpNackReport}
            />
            <Route
              path="/emea/reports/spnack"
              exact
              component={SpNackReport}
            />
             <Route
              path="/emea/Admin"
              exact
              component={AdminReport}
            />
             <Route
              path="/dao/Admin"
              exact
              component={AdminReport}
            />
             <Route
              path="/apj/Admin"
              exact
              component={AdminReport}
            />
<Route
              path="/apj/reports/sn-summary"
              exact
              component={SnSummaryReport}
            />
            <Route
              path="/dao/reports/sn-summary"
              exact
              component={SnSummaryReport}
            />
            <Route
              path="/emea/reports/sn-summary"
              exact
              component={SnSummaryReport}
            />
            <Route
              path="/apj/reports/sn-hold-log"
              exact
              component={SnHoldReport}
            />
            <Route
              path="/dao/reports/sn-hold-log"
              exact
              component={SnHoldReport}
            />
            <Route
              path="/emea/reports/sn-hold-log"
              exact
              component={SnHoldReport}
            />

            
          </Switch>
        </Router>
      </div>
    </>
  );
}

export default App;
