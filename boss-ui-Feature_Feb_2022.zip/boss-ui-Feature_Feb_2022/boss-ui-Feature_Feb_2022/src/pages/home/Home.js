import React from "react";
import "App.css";
import Cards from "components/cards/Cards";
import "components/cards/Cards.css";
import Footer from "components/footer/Footer";
import "pages/home/Home.css";
import Navbar from "components/navbar/Navbar";

function Home() {
  return (
    <>
      <div
        style={
          {
            //backgroundImage: `url("https://www.itl.cat/pngfile/big/96-961951_network-connection-platform-world-global-gis-tavos.jpg")`,backgroundRepeat: 'no-repeat',width:'100%',height:'2000px',color:'white'
          }
        }
      >
        <Navbar />

        {/* <ImageSlider  slides={SliderData}/>  */}
        <Cards />
        <Footer />
        {/* <Footer/>  */}
      </div>
    </>
  );
}

export default Home;
