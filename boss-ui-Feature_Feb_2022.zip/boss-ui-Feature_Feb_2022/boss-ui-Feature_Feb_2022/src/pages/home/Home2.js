import { React, useState, useLayoutEffect } from "react";
import Cards from "components/cards/Cards";
import Footer from "components/footer/Footer";
import PrimarySearchAppBar2 from "components/appbar/AppBar";

export const Home2 = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
      <div>
        <PrimarySearchAppBar2 user={user} email={email} />
        <Cards />
        <Footer />
      </div>
      {/* )} */}
    </>
  );
};
export default Home2;
