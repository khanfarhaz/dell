import React from "react";
import "pages/region/RegionPage.css";
import RegionCardItem from "pages/region/RegionCardItem";
import daoImage from "images/DAO.jpg";
import emeaImage from "images/emea.jpg";
import apjImage from "images/apj.jpg";

function RegionPage() {
  return (
    <>
      <div className="regioncards__wrapper">
        <ul className="regioncards__items">
          <RegionCardItem
            src={emeaImage}
            text=""
            label="EMEA Region"
            path="/emea"
          />
          <RegionCardItem
            src={daoImage}
            text=""
            label="DAO Region"
            path="/dao"
          />
          <RegionCardItem
            src={apjImage}
            text=""
            label="APJ Region"
            path="/apj"
          />
        </ul>
      </div>
    </>
  );
}

export default RegionPage;
