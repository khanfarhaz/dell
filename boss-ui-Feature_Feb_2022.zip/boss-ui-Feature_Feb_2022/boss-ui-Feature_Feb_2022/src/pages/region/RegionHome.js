import { React, useState, useLayoutEffect } from "react";
import "App.css";
import RegionPage from "pages/region/RegionPage";
import PrimarySearchAppBar2 from "components/appbar/AppBar";
import Footer from "components/footer/Footer";

function RegionHome() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
      <div>
        <PrimarySearchAppBar2 user={user} email={email} />
        <RegionPage />
        <Footer />
      </div>
      {/* )} */}
    </>
  );
}

export default RegionHome;
