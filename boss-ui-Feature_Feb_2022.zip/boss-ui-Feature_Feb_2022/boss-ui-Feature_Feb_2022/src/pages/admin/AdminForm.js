import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import { nanoid } from "nanoid";
import "components/tables/AddDeleteTable/admintable.css";
//import data from "./mock-data.json";
import ReadOnlyRow from "components/tables/AddDeleteTable/ReadOnlyRow";
import EditableRow from "components/tables/AddDeleteTable/EditableRow";
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
//import Dropdown from'./components/dropdown/Dropdown';
import { useTheme } from '@mui/material/styles';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import NativeSelect from '@mui/material/NativeSelect';
import InputBase from '@mui/material/InputBase';
import { styled } from '@mui/material/styles';
import Checkbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import FormHelperText from '@mui/material/FormHelperText';
import { useRouteMatch } from "react-router-dom";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormLabel from '@mui/material/FormLabel';
import ReactTable from 'react-table-6';
import { useTableSearch } from '@kvraamkey/react-table-global-search';
import LoadingSpinner from "components/loadingspinner/LoadingSpinner";
import { ReactTableDefaults } from "react-table-6";
//import '@kvraamkey/table-global-search/dist/index.css';
//import 'react-table-6/react-table.css';
import 'components/tables/AddDeleteTable/deltable.css';
//import LoadingSpinner from "./LoadingSpinner.js";
// const user=
// [
//   {
//     "id":1,
//     "loginName": "Jenny Chan",
//     "roleName": "role 1, role 2, role 3"
    
//   },
//   { "id":2,
//     "loginName": "Jessica warren",
//     "roleName": "role 2, 3, 7"
   
//   },
//   { "id":3,
//     "loginName": "Tony Frank",
//     "roleName": "role 6"
//   },
//   { "id":4,
//     "loginName": "Jeremy Clark",
//     "roleName": "role 2,4,5"
//   },
//   {"id":5,
//     "loginName": "Raymond Edwards",
//     "roleName": "role 3"
//   },
//   {
//     "id":1,
//     "loginName": "Jenny Chan",
//     "roleName": "role 1, role 2, role 3"
    
//   },
//   { "id":2,
//     "loginName": "Jessica warren",
//     "roleName": "role 2, 3, 7"
   
//   },
//   { "id":3,
//     "loginName": "Tony Frank",
//     "roleName": "role 6"
//   },
//   { "id":4,
//     "loginName": "Jeremy Clark",
//     "roleName": "role 2,4,5"
//   },
//   {"id":5,
//     "loginName": "Raymond Edwards",
//     "roleName": "role 3"
//   }
// ]
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent:LoadingSpinner                                                            
});

export const AdminPage = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];
 

  const [addFormData, setAddFormData] = useState({
    user: "",
    role: "",
  });
  const [addRoleFromData, setAddRoleFormData] = useState({
    user: "",
    role: "",
  });

  const [open, setOpen] = React.useState(false);
  const [roleopen, setRoleOpen] = React.useState(false);
  
  const [delopen, setdelOpen] = React.useState(false);
  const [editContactId, setEditContactId] = useState(null);
  const [user, setUser] = useState([]);
  //uncomment below anduncomment uselayout effect
  const [data, setData] = useState([]);
  //const [data, setData] = useState([mockdata]);
  const [selectedUser, setSelectedUser] = useState("");

  	
const [newkey, setKey] = useState("");
const [id, setId] = useState("");

  const [singleuser, setSingleUser] = React.useState('');
const [roleName, setRoleName] = React.useState([]);
  const [admindata,setAdminData]= useState(null);
  const [radiovalue, setRadioValue] = React.useState('');

  const [age, setAge] = React.useState('');
  const[role,setRole]= useState([]);

  let url="";
   if (reqRegion === "dao") {
     url = "https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/";
   } else {
     url = "https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/";
   }

  const handleUserChange = (event) => {
    setSingleUser(event.target.value);
    console.log("user value", singleuser);
  };

  const handleRadioSelect= (event) => {
    setRadioValue(event.target.value);
    //console.log("user value", value);
  };

  
  const handledelClickOpen = () => {
    setdelOpen(true);
  };

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleRoleClickOpen = () => {
    setRoleOpen(true);
  };


  const handledelClose = () => {
    setdelOpen(false);
    
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleRoleClose = () => {
    setRoleOpen(false);
  };

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

useLayoutEffect(() => {
  const arr = [];
  
fetch(url+"getAllRoles",
{
headers : { 
  'Content-Type': 'application/json',
  'Accept': 'application/json'
 }
})
//fetch("http://localhost:8080/getAllUsers")
  .then((response) => response.json())
  .then((odata) => {
    console.log("get roles data",odata)
    odata.map((item, i) => {
      arr.push(item.role);
    });
    setRole(arr);
    console.log("roles data",role)
  });
}, []);

useLayoutEffect(() => {
  const arr = [];
  //change the url here to getAllUsers
fetch(url+"getAllUsers", 
{
  headers : { 
    'Content-Type': 'application/json',
    'Accept': 'application/json'
   }
  })
  .then((response) => response.json())
  .then((odata) => {
    console.log("get users data received",odata)
    odata.map((item, i) => {
      //chnage this to item.user
      arr.push(item.user);
    });
    setData(arr);
    console.log("user data",data)
  }
  );
}, []);
 
const [loading, setLoading] = useState(true);  

//get user and roles 
useLayoutEffect(() => {
  setLoading(true);
  const arr = [];
  
fetch(url+"getuserandroles", 
{
  headers : { 
    'Content-Type': 'application/json',
    'Accept': 'application/json'
   }
  })
  .then((response) => response.json())
  .then((odata) => {
    console.log("get users data received",odata)
    odata.map((item, i) => {
      //chnage this to item.user
      arr.push(item);
    });
    setUser(arr);
    console.log("user data",user)
    setLoading(false);
  }
  );
}, []);
const [searchVal, setSearchVal] = React.useState(null);

  const { filteredData } = useTableSearch({
    searchVal,
    retrieve: user
  });
 

const [contacts, setContacts] = useState(user);

function getStyles(name, roleName, theme) {
  return {
    fontWeight:
    roleName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}


  const theme = useTheme();
  //const [roleName, setRoleName] = React.useState([]);


  
  const handleSearch = () => {
    const adminsetdata={
     // userName:singleuser,
      userName:singleuser,
      expiryDate:radiovalue,
      roles:roleName
     // vendor: selectedVendor
    }
    setAdminData(adminsetdata);
  
    console.log("admin data", JSON.stringify(adminsetdata));

    fetch(url+"addRoleForUser", {
      method: "POST",
      body: JSON.stringify(adminsetdata),
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        
        console.log(data,"returned data");
        
      });
      window.location.reload();

    //handleReset();
    }

  const handleMultiSelectChange = (event) => {
    const {
      target: { value },
    } = event;
    setRoleName(
      typeof value === 'string' ? value.split(',') : value,
    );
    console.log("multi user selected", roleName)
  };


  // useLayoutEffect(() => {
    
  //     //const url = "https://getvendors-ge2-emea.ausvtc01.pcf.dell.com/getVendors"
    
  //   const arr = [];
  //   fetch("http://localhost:8080/getAllRoles")
  //     .then((response) => response.json())
  //     .then((data) => {
  //       data.map((item, i) => {
  //         arr.push(item.vendorName);
  //       });

  //       setUser(arr);
  //     });
  // }, []);

  const sendDataToParent = (name,value) => {
    // if (name === "user") {
    //   setSelectedUser(value);
    //   console.log("selected user is", value);
    // }
    // else if(name ==="role")
    // {
    //   setRoleName(value);
    //   console.log("selected role is", value);
    // }
    // if (name === "Vendor") {
    //   setSelectedVendor(value);
    //   console.log("value of vendor is", selectedVendor);
    // } 
    setSelectedUser(value);
    console.log("value of user", singleuser)
  };
  
//   useLayoutEffect(() => {
    
//     //const url = "https://getvendors-ge2-emea.ausvtc01.pcf.dell.com/getVendors"
  
//   const rolearr = [];
//   fetch("https://getvendors-ge2-emea.ausvtc01.pcf.dell.com/getVendors")
//     .then((response) => response.json())
    
//     .then((data) => {
//       console.log("role response", data)
      
//       rolearr.push(data.role);
      
//       // data.map((item, i) => {
//       //   rolearr.push(item.roles);
//       // });

//       setRole(rolearr);
//     });
// }, []);

//   const sendDataToParent = (value) => {
//       setSelectedUser(value);
    
//   };


  const handleAddFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...addFormData };
    newFormData[fieldName] = fieldValue;

    setAddFormData(newFormData);
  };

  const handleAddRoleFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    console.log("fieldname", fieldName)
    const fieldValue = event.target.value;

    const newFormData = { ...addRoleFromData };
    newFormData[fieldName] = fieldValue;

    setAddRoleFormData(newFormData);
  };

  const handleAddFormSubmit = (event) => {
    event.preventDefault();

    const newContact = {
      userName: addFormData.user,
    };

    console.log("stringified data",JSON.stringify(newContact))
    const newContacts = [...contacts, newContact];
    setContacts(newContacts);
    
    fetch(url+"adduser", {
      method: "POST",
      body: JSON.stringify(newContact),
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        
        console.log(data,"returned data");
        
      });
    handleClose();
   window.location.reload();
  };

  const handleAddRoleFormSubmit = (event) => {
    event.preventDefault();
console.log("add role form data",addRoleFromData);
    const newContact = {
      //id: nanoid(),
      roleName:addRoleFromData.user
    };

    console.log("stringified data",JSON.stringify(newContact))
    const newContacts = [...contacts, newContact];
    setContacts(newContacts);
    
    fetch(url+"addRole", {
      method: "POST",
      body: JSON.stringify(newContact),
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        
        console.log(data,"returned data");
        
      });
    handleRoleClose();
    window.location.reload();

  };

  const handleDeleteClick = () => {
   //console.log("contactid", contactId)
    // const newContacts = [...contacts];
    // console.log("new contacts", newContacts)
    
    // const index = contacts.findIndex((contact) => contact.loginName === id);
    // const data = contacts.find((contact) => contact.loginName === id);
    // console.log("data found",data);
    // //const deleteData={user:data}
  
    // newContacts.splice(index, 1);
    // setContacts(newContacts);

    const deleteData={userName:id}
    console.log("id in handle delete is", JSON.stringify(deleteData));
    fetch(url+"deleteuser", {
      method: "POST",
      body: JSON.stringify(deleteData),
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        
        console.log(data,"returned data");
        
      });
      handledelClose();
      window.location.reload();
  };

  
const onRowClick = (state, rowInfo, column, instance) => {

	
	const handleClickGroup=()=>{
		//console.log("new key", newkey);
		handledelClickOpen()
	}
    return {
        onClick: e => {
            console.log('It was in this row:', rowInfo.row)
			console.log('Id please:', rowInfo.row._original.loginName)
			
			//setKey(rowInfo.row.user);
			setId(rowInfo.row._original.loginName)
       console.log("id is",id);
			handleClickGroup()
			
        }
    }
}

const columns = [
  {
    width: 300,
    Header: "User",
    accessor: "loginName"
  },
  {
    width: 300,
    Header: "Roles",
    accessor: "roleName"
  },
  {
    width: 100,
    Header: "Action",
  Cell: ({value}) => (<Button variant="outlined"
  type="button" onClick={onRowClick}>Delete</Button>)
  }
];

  return (
    <div>


<div className="uIformcards_asbuilt">
          <div className="uIformcards__container_asbuilt">
            <div className="narrative_asbuilt"> Admin Page</div>
      
        <div className="uIformcards_asbuilt">
       
          <div className="uIformcards__container_asbuilt_type2">
            <div className="narrative_asbuilt_type2"> View User and Roles</div>
            

            <div className="uIformcards__container_asbuilt">

                  {/* <div className="formcards__wrapper_row">
                       <ul className="formcards__items">
                          <ReactTable
                            data={data}
                            columns={columns}
                            minRows={0}
                            className='table'
                            showPagination={true}
                            pageSize={5}
                            //getTdProps={data.user}
                          getTrProps={onRowClick}
                          
                            />
                   
                        </ul>    
                  </div> */}
                  <div className="formcards__wrapper_row">
                      <ul className="formcards__items">
                  <div className="globalfilter">
                      <input
                        onChange={(e) => setSearchVal(e.target.value)}
                        type="text"
                        className='globalfilter'
                        placeholder='Search'
                      />
                    </div>
                    </ul>
                    </div>

                <div className="uIformcards_asbuilt">
                <div className='search-bar w3-margin-bottom w3-margin-top'>
                

                  </div>
                
                <ReactTable
                            data={filteredData}
                            columns={columns}
                            minRows={0}
                            className='table'
                            showPagination={true}
                            defaultPageSize={5} 
                            sortable={true}
                            loading={loading}
                            //getTdProps={data.user}
                          getTrProps={onRowClick}
                          
                            />
                                                    <Dialog
                                                      open={delopen}
                                                      onClose={handledelClose}
                                                      aria-labelledby="alert-dialog-title"
                                                      aria-describedby="alert-dialog-description"
                                                    >
                                                  
                                                      <DialogContent>
                                                        <DialogContentText id="alert-dialog-description"color="0076ce">
                                                          Are you sure you want to delete a user?
                                                        </DialogContentText>
                                                      </DialogContent>
                                                      <DialogActions>
                                                        <Button onClick={handledelClose}>No</Button>
                                                        <Button onClick={handleDeleteClick} autoFocus >
                                                          Yes
                                                        </Button>
                                                      </DialogActions>
                                                    </Dialog>


                                                    <Dialog
                                                      open={roleopen}
                                                      onClose={handleRoleClose}
                                                      aria-labelledby="alert-dialog-title"
                                                      aria-describedby="alert-dialog-description"
                                                    >
                                                  
                                                      <DialogContent>
                                                        <DialogContentText id="alert-dialog-description"color="0076ce">
                                                          Are you sure you want to add a role?
                                                        </DialogContentText>
                                                      </DialogContent>
                                                      <DialogActions>
                                                        <Button onClick={handleRoleClose}>No</Button>
                                                        <Button onClick={handleAddRoleFormSubmit} autoFocus >
                                                          Yes
                                                        </Button>
                                                      </DialogActions>
                                                    </Dialog>


                                                    

                  <div className="uIformcards__container_asbuilt_type2">
                    
                    <div className="narrative_asbuilt_type2"> Add Users or Roles</div>
           
                    <div className="formcards__wrapper_row">
                      <ul className="formcards__items">
                        <div className="inputfield">
             
                          <form onSubmit={handleAddFormSubmit}>
                            <input
                              type="text"
                              name="user"
                              required="required"
                              placeholder="Enter User to be added..."
                              onChange={handleAddFormChange}
                            />
                          <Button variant="outlined" onClick={handleClickOpen}>
                            Add User
                          </Button>
                          </form>
                         </div>


                          <form onSubmit={handleAddRoleFormSubmit}>
                            <input
                              type="text"
                              name="user"
                              required="required"
                              placeholder="Enter Role to be added..."
                              onChange={handleAddRoleFormChange}
                            />
                          <Button variant="outlined" onClick={handleRoleClickOpen}>
                            Add Role
                          </Button>
                          </form>
                        </ul>
                    </div>

                            <div className="uIformcards_asbuilt">
                                  <div className="uIformcards__container_asbuilt_type2">
                                    
                                    <div className="narrative_asbuilt_type2"> Add Roles for a User</div>
                                      <div className="uIformcards__container_asbuilt">
                                         <div className="formcards__wrapper_row">
                                            <ul className="formcards__items">
                                                <div>
                                               

                                                    <Dialog
                                                      open={open}
                                                      onClose={handleClose}
                                                      aria-labelledby="alert-dialog-title"
                                                      aria-describedby="alert-dialog-description"
                                                    >
                                                  
                                                      <DialogContent>
                                                        <DialogContentText id="alert-dialog-description"color="0076ce">
                                                          Are you sure you want to add a user?
                                                        </DialogContentText>
                                                      </DialogContent>
                                                      <DialogActions>
                                                        <Button onClick={handleClose}>No</Button>
                                                        <Button onClick={handleAddFormSubmit} autoFocus >
                                                          Yes
                                                        </Button>
                                                      </DialogActions>
                                                    </Dialog>
                                                </div>
                                            <div className="sectionthree">
  
                                              <FormControl sx={{ m: 1, width: 250 }}>
                                                  <InputLabel id="demo-simple-select-helper-label">All Users</InputLabel>
                                                  <Select
                                                    labelId="demo-simple-select-helper-label"
                                                    id="demo-simple-select-helper"
                                                    name={"All Roles"}
                                                                  listItems={data}
                                                                  //sendDataToParent={sendDataToParent}
                                                                  value={singleuser}
                                                    label="All Users"
                                                    onChange={handleUserChange}
                                                  >
                                                  {data.map((user) => (
                                                              <MenuItem
                                                                key={user}
                                                                value={user}
                                                              >
                                                                {user}
                                                              </MenuItem>
                                                            ))}
                                                  </Select>
                                                  <FormHelperText></FormHelperText>
                                                </FormControl>

                                                <FormControl sx={{ m: 1, width: 300 }}>
                                                            <InputLabel id="demo-multiple-checkbox-label">All Roles</InputLabel>
                                                            <Select
                                                              labelId="demo-multiple-checkbox-label"
                                                              id="demo-multiple-checkbox"
                                                              multiple
                                                              value={roleName}
                                                              onChange={handleMultiSelectChange}
                                                              input={<OutlinedInput label="All Roles" />}
                                                              renderValue={(selected) => selected.join(', ')}
                                                              MenuProps={MenuProps}
                                                            >
                                                            {role.map((user) => (
                                                              <MenuItem
                                                                key={user}
                                                                value={user}
                                                                // style={getStyles(user, roleName, theme)}
                                                              >
                                                                <Checkbox checked={roleName.indexOf(user) > -1} />
                                                                <ListItemText primary= {user}/>
                                                              </MenuItem>
                                                            ))}
                                                          </Select>
                                                  </FormControl>

                                                  <FormControl component="fieldset">
                                                  <FormLabel component="legend">Expiration Policy: </FormLabel>
                                          
                                                    <RadioGroup row aria-label="gender" name="row-radio-buttons-group" onChange={handleRadioSelect} value={radiovalue}>
                                                    <FormControlLabel value="90"  control={<Radio />} label="3 Months" />
                                                    <FormControlLabel value="180" control={<Radio />} label="6 Months" />
                                                    <FormControlLabel value="50000" control={<Radio />} label="Never" />
                                                    {/* <FormControlLabel
                                                      value="disabled"
                                                      disabled
                                                      control={<Radio />}
                                                      label="other"
                                                    /> */}
                                                </RadioGroup>
                                                </FormControl>
    
                                                  <div className="outlinedbtn">
                                                    <Button variant="outlined"
                                                    type="button"
                                                    onClick={handleSearch}
                                                  >
                                                    ADD
                                                  </Button>
                                                  </div>

                    
                  
                                              </div>
                                          </ul>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    
                  </div>
              </div> 
        </div> 
     </div>
  </div>
  </div>
  </div>
  );







};

