export const AsnSubDetailPartDetailColumns = [
  {
    Header: "Sub Line Item",
    accessor: "subLineItem",
  },
  {
    Header: "As Ordered Part #",
    accessor: "asOrderedPartNum",
  },
  {
    Header: "AsBuilt Part Num",
    accessor: "asBuiltPartNum",
  },
  {
    Header: "Part Qty",
    accessor: "partQty",
  },
];
