const AdminProperties = {
  getAllRolesDAO:"https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/getAllRoles",
  getAllRolesEMEA:"https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/getAllRoles",
  getAllUsersDAO:"https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/getAllUsers",
  getAllUsersEMEA:"https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/getAllUsers",
  addRoleDAO:"https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/addRole",
  addRoleEMEA:"https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/addRole",
  addRoleForUserDAO:"https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/addRoleForUser",
  addRoleForUserEMEA:"https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/addRoleForUser",
  deleteuserDAO:"https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/deleteuser",
  deleteuserEMEA:"https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/deleteuser",
  adduserDAO:"https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/adduser",
  adduserEMEA:"https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/adduser",
  getuserandrolesDAO:"https://admin-service-ui-dao-ge2.pnp3.pcf.dell.com/getuserandroles",
  getuserandrolesEMEA:"https://admin-service-ui-emea-ge2.pnp3.pcf.dell.com/getuserandroles",
};
export default AdminProperties;
