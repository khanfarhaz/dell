import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/asnsummary/AsnSummary.css";
import AsnProperties from "pages/reports/asnsummary/AsnProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/asnsummary/AsnSummaryColumns";
import moment, { isMoment } from "moment";

export const AsnSummary = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [asnSummaryData, setAsnSummaryData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [salesOrder, setSalesOrder] = useState("");
  const [hawbNumber, setHawbNumber] = useState("");
  const [asnNum, setAsnNum] = useState("");
  const [agreementId, setAgreementId] = useState("");
  const [shipMode, setShipMode] = useState([]);
  const [mergeCenterId, setMergeCenterId] = useState("");
  const [region, setRegion] = useState("");
  const [selectedVendor, setSelectedVendor] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);
  const [vendor, setVendor] = useState([]);
  const [serviceTag, setServiceTag] = useState("");
  const [manifestId, setManifestId] = useState("");
  const [selectedShipMode, setSelectedShipMode] = useState("");

  const handleSearch = () => {
    const start = new Date(); //to time the service call
    setIsLoading(true);
    setAsnSummaryData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = moment.utc(toDate);
      fromDateFormat = moment.utc(fromDate);
    }

    const data = {
      vendorName: selectedVendor,
      salesOrderNum: salesOrder,
      hawbNum: hawbNumber,
      asnNum: asnNum,
      agreementId: agreementId,
      shipMode: selectedShipMode,
      mergeCenterId: mergeCenterId,
      beginCreationDate: fromDateFormat,
      endCreationDate: toDateFormat,
      manifestId: manifestId,
      serviceTag: serviceTag,
      demandRegion: region,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    // console.log(data);
    let url;

    if (reqRegion === "dao") {
      url = AsnProperties.asnSummaryDAO;
    } else {
      url = AsnProperties.asnSummaryEMEA;
    }

    console.log(JSON.stringify(data));
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setAsnSummaryData(data);
        // console.log(data);
        setIsLoading(false);
        setTime(new Date() - start); //total time
      });
  };

  const sendDataToParent = (name, value) => {
    if (name === "Vendor") {
      setSelectedVendor(value);
    } else if (name === "ShipMode") {
      setSelectedShipMode(value);
    } else if (name === "DemandRegion") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false);
    setSalesOrder("");
    setHawbNumber("");
    setAsnNum("");
    setAgreementId("");
    setMergeCenterId("");
    setRegion("");
    setSelectedVendor("");
    setServiceTag("");
    setSelectedShipMode("");
    checked.checkedB = false;
    setCheckedSvcTag(false);
    setAsnSummaryData(null);
  };

  //uncomment for vendor

  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = AsnProperties.getVendorListDAO;
    } else {
      url = AsnProperties.getVendorListEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          arr.push(item.vendorName);
        });

        setVendor(arr);
      });
  }, []);
  
  //uncomment for shipmode

  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = AsnProperties.getShipModeDAO;
    } else {
      url = AsnProperties.getShipModeEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          if (item != null) {
            arr.push(item.shipmodeName);
          }
        });

        setShipMode(arr);
        console.log(arr);
      });
  }, []);

  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">Advance Ship Notice Summary</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="Sales Order"
                      onChange={(e) => setSalesOrder(e.target.value)}
                      value={salesOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Hawb Number"
                      onChange={(e) => setHawbNumber(e.target.value)}
                      value={hawbNumber}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Asn Num"
                      onChange={(e) => setAsnNum(e.target.value)}
                      value={asnNum}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Manifest Id"
                      onChange={(e) => setManifestId(e.target.value)}
                      value={manifestId}
                      disabled={checkedSvcTag}
                    />
                  </div>
                </ul>
              </div>
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"ShipMode"}
                        listItems={shipMode}
                        sendDataToParent={sendDataToParent}
                        value={selectedShipMode}
                        disabled={checkedSvcTag}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"DemandRegion"}
                        listItems={AsnProperties.region}
                        sendDataToParent={sendDataToParent}
                        value={region}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                        value={selectedVendor}
                      />
                    </label>
                  </div>
                  {reqRegion !== "dao" && (
                    <div className="component">
                      <TextInput
                        name="Agreement Id"
                        onChange={(e) => setAgreementId(e.target.value)}
                        value={agreementId}
                        disabled={checkedSvcTag}
                      />
                    </div>
                  )}
                </ul>
              </div>
              <div className="formcards__wrapper_row3">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="Merge Center ID"
                      onChange={(e) => setMergeCenterId(e.target.value)}
                      value={mergeCenterId}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Service Tag"
                      onChange={(e) => setServiceTag(e.target.value)}
                      value={serviceTag}
                      disabled={!checkedSvcTag}
                    />
                  </div>
                  <div className="checkbox_svctag">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkedSvcTag}
                          onChange={handleChangeSvcTag}
                          name="checkedSvcTag"
                          color="primary"
                        />
                      }
                      label="Svc Tag"
                    />
                  </div>
                </ul>
              </div>
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  <div className="component_from_date_asnsummary">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_asnsummary">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_asnsummary">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                </ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-asnsummary"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-asnsummary"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper">
        {/* <div className="time_div"> */}
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}
{/* 
          {asnSummaryData && (
            <label className="rows" htmlFor="text">
              Rows : {rows}
            </label>
          )}

          {asnSummaryData && (
            <label className="rows" htmlFor="text">
              Time : {time}ms
            </label>
          )} */}
        {/* </div> */}
        {/* <div className="result__wrapper"> */}
        <div className="table_container">

            <div className="table_wrapper">
          {asnSummaryData && (
            <BasicTable tdata={asnSummaryData} columns={COLUMNS} tablename={"emp-table"} filename={"AsnSummary"} rows={rows} time={time}/>
          )}
          </div>
          </div>
        </div>
      </div>
    </>
  );
};
