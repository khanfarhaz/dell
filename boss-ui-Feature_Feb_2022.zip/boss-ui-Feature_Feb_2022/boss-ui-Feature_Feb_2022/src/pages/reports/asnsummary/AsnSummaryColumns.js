export const COLUMNS = [
  {
    Header: "Vendor",
    accessor: "vendorName",
  },
  {
    Header: "Air WayBill",
    accessor: "airwayBillNum",
  },
  {
    Header: "Asn Num",
    accessor: "asnNum",
    Cell: (e) => (
      <a
        href={`asn-detail?asn=${e.value}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        {e.value}
      </a>
    ),
  },
  {
    Header: "Demand Region",
    accessor: "region",
  },
  {
    Header: "Pallet Total",
    accessor: "palletTotal",
  },
  {
    Header: "Tot Qty",
    accessor: "totalShipQty",
  },
  {
    Header: "Po Qty",
    accessor: "poqty",
  },
  {
    Header: "SVCTag Qty",
    accessor: "totSVCTagQty",
  },
  {
    Header: "Merge Ctr Id",
    accessor: "mergeCenterID",
  },
  {
    Header: "PO",
    accessor: "blanketPoNum",
  },
  {
    Header: "Shipper",
    accessor: "shipperID",
  },
  {
    Header: "Ship Date",
    accessor: "shipDate",
  },
  {
    Header: "Created By",
    accessor: "createdBy",
  },
  {
    Header: "1st Pallet Received Date",
    accessor: "firstPalletDate",
  },
  {
    Header: "All Pallet Received Date",
    accessor: "palletDate",
  },
  {
    Header: "Glovia Ack Date",
    accessor: "asnackDate",
  },
  {
    Header: "VOI Date",
    accessor: "voidate",
  },
  {
    Header: "ShipMode",
    accessor: "shipMode",
  },
];
