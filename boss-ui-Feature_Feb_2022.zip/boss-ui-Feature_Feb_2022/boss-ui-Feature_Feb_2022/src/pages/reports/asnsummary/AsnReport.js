import { React, useState, useLayoutEffect } from "react";
import { AsnSummary } from "pages/reports/asnsummary/AsnSummary";
import PrimarySearchAppBar from "components/appbar/AppBarWithSideNav";

export const AsnReport = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
      <div>
        <PrimarySearchAppBar user={user} email={email} />
        <AsnSummary />
      </div>
      {/* )} */}
    </>
  );
};
