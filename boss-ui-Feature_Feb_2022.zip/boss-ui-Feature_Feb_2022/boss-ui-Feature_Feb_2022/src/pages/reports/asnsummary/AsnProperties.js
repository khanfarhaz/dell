const AsnProperties = {
  region: ["DAO", "EMEA", "APJ"],

  // getVendorListEMEA:
  //   "https://getvendors-ge2-emea.ausvtc01.pcf.dell.com/getVendors",
  // getVendorListDAO:
  //   "https://getvendors-ge2-dao.ausvtc01.pcf.dell.com/getVendors",
  // asnSummaryDAO:
  //   "https://asnsummary-service-ge2-dao.ausvtc01.pcf.dell.com/getasnsummary",
  // asnSummaryEMEA:
  //   "https://asnsummary-service-ge2-emea.ausvtc01.pcf.dell.com/getasnsummary",
  // getShipModeDAO:
  //   "https://getshipmode-service-ge2-dao.ausvtc01.pcf.dell.com/getShipmode",
  // getShipModeEMEA:
  //   "https://getshipmode-service-ge2-emea.ausvtc01.pcf.dell.com/getShipmode",

  getVendorListEMEA:
    "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
  getVendorListDAO:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",
  asnSummaryDAO:
    "https://asnsummary-ui-dao-ge4.pnp3.pcf.dell.com/getasnsummary",
  asnSummaryEMEA:
    "https://asnsummary-ui-emea-ge2.pnp3.pcf.dell.com/getasnsummary",
  getShipModeDAO:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getshipmode",
  getShipModeEMEA:
    "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getshipmode",
};


export default AsnProperties;
