const ThreePlOutboundProperties =  {
  get3PLVendorListEMEA:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getthreeplvendor",
  get3PLVendorListDAO:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getthreeplvendor",

  threePlDAO:
    "https://3pl-ui-ge2.pnp3.pcf.dell.com/getoutboundasnreceiptnack",
  threePlEMEA:
    "https://3pl-ui-ge2.pnp3.pcf.dell.com/getoutboundasnreceiptnack",

 
};
export default ThreePlOutboundProperties;
