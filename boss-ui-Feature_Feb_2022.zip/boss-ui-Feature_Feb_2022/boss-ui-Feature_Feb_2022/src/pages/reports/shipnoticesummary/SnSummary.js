import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/shipnoticesummary/SnSummary.css";
import SnProperties from "pages/reports/shipnoticesummary/SnSummaryProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/shipnoticesummary/SnSummaryColumns";
import moment, { isMoment } from "moment";

export const SnSummary = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [asnSummaryData, setAsnSummaryData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [asnNum, setAsnNum] = useState("");
  const [snNum, setSnNum] = useState("");
  const [selectedVendor, setSelectedVendor] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);
  const [vendor, setVendor] = useState([]);
 

  const handleSearch = () => {
    const start = new Date(); //to time the service call
    setIsLoading(true);
    setAsnSummaryData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = moment.utc(toDate);
      fromDateFormat = moment.utc(fromDate);
    }

    const data = {
      vendor: selectedVendor,
      asnNum: asnNum,
      snNum: snNum,
      fromDate: fromDateFormat,
      endDate: toDateFormat,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    // console.log(data);
    let url;

    if (reqRegion === "dao") {
      url = SnProperties.snSummaryDAO;
    } else {
      url = SnProperties.snSummaryEMEA;
    }

    console.log(JSON.stringify(data));
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setAsnSummaryData(data);
        // console.log(data);
        setIsLoading(false);
        setTime(new Date() - start); //total time
      });
  };

  const sendDataToParent = (name, value) => {
    if (name === "Vendor") {
      setSelectedVendor(value);
    } 
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false); 
    setAsnNum("");
    setSnNum("");
    setSelectedVendor("");   
    checked.checkedB = false;
    setAsnSummaryData(null);
  };

  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = SnProperties.getVendorListDAO;
    } else {
      url = SnProperties.getVendorListEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          arr.push(item.vendorName);
        });

        setVendor(arr);
      });
  }, []);

  

  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">Ship Notice Summary Page</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                <div className="component_snsummary">
                    <label>
                      <Dropdown
                        name={"Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                        value={selectedVendor}
                      />
                    </label>
                  </div>
                  <div className="component_snsummary">
                    <TextInput
                      name="SN Num"
                      onChange={(e) => setSnNum(e.target.value)}
                      value={snNum}
                      
                    />
                  </div>
                  <div className="component_snsummary">
                    <TextInput
                      name="ASN Num"
                      onChange={(e) => setAsnNum(e.target.value)}
                      value={asnNum}
                      
                    />
                  </div>
                  
                </ul>
              </div>
              
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  <div className="component_from_date_snsummary">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_snsummary">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_snsummary">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                </ul>
                <ul className="formcards__items">
                  <div className="component_search_snsummary">
                    <button
                      type="button"
                      className="btnnew-onhold_asnsummary"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_reset_snsummary">
                    <button
                      type="button"
                      className="btnnew-onhold_asnsummary"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper"> 
          <ColoredLine color="#0076ce" />
          {isLoading && <LoadingCircle />}
                
          {asnSummaryData && (
            <BasicTable tdata={asnSummaryData} columns={COLUMNS} tablename={"emp-table"} filename={"ShipNoticesSummary"} rows={rows} time={time}/>
         )} 
        </div>
      </div>
    </>
  );
};
