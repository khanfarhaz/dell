export const COLUMNS = [
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "SN NUM",
    accessor: "snNum",
  },
  {
    Header: "Asn Num",
    accessor: "asnNum",
    Cell: (e) => (
      <a
        href={`asn-detail?asn=${e.value}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        {e.value}
      </a>
    ),
  },
  {
    Header: "Status Desc",
    accessor: "statusDesc",
  },
  {
    Header: "Created Date",
    accessor: "dateCreated",
  },
  
];
