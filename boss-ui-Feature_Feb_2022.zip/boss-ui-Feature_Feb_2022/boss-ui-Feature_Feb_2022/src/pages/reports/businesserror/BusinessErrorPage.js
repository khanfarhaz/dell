import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/businesserror/BusinessErrorPage.css";
import BusinessErrorPageProperties from "pages/reports/businesserror/BusinessErrorPageProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/businesserror/BusinessErrorPageColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";

export const BusinessErrorPage = () => {
  
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };
  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [systemErrorData, setSystemErrorData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [salesOrder, setSalesOrder] = useState("");
  const [globalproductionOrder, setGlobalProductionOrderNumber] = useState("");
  
  const [region, setRegion] = useState("");
  

  const [serviceTag, setServiceTag] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);

  const [vendor, setVendor] = useState("");
  //const [selectedVendor, setSelectedVendor] = useState("");

  // const [mergeCenterId, setMergeCenterId] = useState("");
  // const [agreementId, setAgreementId] = useState("");
  
  // const [vendorWorkOrder, setVendorWorkOrderNum] = useState("");
  // const [baseType, setBaseType] = useState("");
 
  // const [orderType, setOrderType] = useState([]);
  // const [selectedOrderType, setSelectedOrderType] = useState("");
  
  // const [locationNo, setLocationNumber] = useState([]);
  // const [selectedLocation, setSelectedLocation] = useState("");

  // const [companyNo, setCompanyNumber] = useState([]);
  // const [selectedCompanyNumber, setSelectedCompanyNumber] = useState("");

  // const [currentStatus, setCurrentStatus] = useState([]);
  // const [selectedCurrentStatus, setSelectedCurrentStatus] = useState("");


  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setSystemErrorData(null);

   
    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = dateFormat(toDate, "yyyy-mm-dd HH:MM:ss");
      fromDateFormat = dateFormat(fromDate, "yyyy-mm-dd HH:MM:ss");
    }


    // if (checked.checkedB === true) {
    //   toDateFormat = moment.utc(toDate);
    //   fromDateFormat = moment.utc(fromDate);
    // }

    const data = {
      vendor: vendor,
      salesOrderNumber: salesOrder,
      gpoNumber: globalproductionOrder,
      fromDate: fromDateFormat,
      toDate: toDateFormat,
      serviceTag: serviceTag,
      //demandRegion: region,
      demandRegion: reqRegion.toUpperCase(),

      // locNumber: selectedLocation,
      // companyNumber:selectedCompanyNumber,
      // statusCode: selectedCurrentStatus,
      // vendorWorkOrder: vendorWorkOrder,
      // agreementId: agreementId,
      // orderType: selectedOrderType,
      // mergeCenterId: mergeCenterId,
      // baseType: baseType,
      
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data,"this is data");
    let url;

    if (reqRegion === "dao") {
      url = BusinessErrorPageProperties.poSummaryDAO;
    } else {
      url = BusinessErrorPageProperties.poSummaryEMEA;
    }

    console.log(JSON.stringify(data),"stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setSystemErrorData(data);
        console.log(data,"returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };

  const sendDataToParent = (name, value) => {
    // if (name === "Vendor") {
    //   setSelectedVendor(value);
    // }
        
    // else 
    if (name === "DemandRegion") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false);
    setSalesOrder("");
    setGlobalProductionOrderNumber("");
    setRegion("");
    setVendor("");
    setServiceTag("");
    checked.checkedB = false;
    setCheckedSvcTag(false);
    setSystemErrorData(null);
  };

  // useLayoutEffect(() => {
  //   let url;
  //   if (reqRegion === "dao") {
  //     url = BusinessErrorPageProperties.getVendorListDAO;
  //   } else {
  //     url = BusinessErrorPageProperties.getVendorListEMEA;
  //   }
  //   const arr = [];
  //   fetch(url)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       data.map((item, i) => {
  //         arr.push(item.vendorName);
  //       });

  //       setVendor(arr);
  //     });
  // }, []);



  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">Business Error Page</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                <div className="component">
                    <TextInput
                      name="Vendor"
                      onChange={(e) => setVendor(e.target.value)}
                      value={vendor}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Global Production Order No"
                      onChange={(e) => setGlobalProductionOrderNumber(e.target.value)}
                      value={globalproductionOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Sales Order Number"
                      onChange={(e) => setSalesOrder(e.target.value)}
                      value={salesOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                 
                
                 
                </ul>
              </div>
              
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  
                                  
                  
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                <div className="component_from_date_asnsummary">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}

                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_asnsummary">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_asnsummary">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                </ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_oppfailed"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_oppfailed"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                  {/* <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={handleReset}
                    >
                      Export to excel
                    </button>
                  </div> */}
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
        <div className="time_div">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}

          {systemErrorData && (
            <label className="rows" >
              Rows : {rows}
            </label>
          )}

          {systemErrorData && (
            <label className="rows" htmlFor="text">
              Time : {time}ms
            </label>
          )}
        </div>
        <div className="result__wrapper">
          {systemErrorData && (
            <BasicTable tdata={systemErrorData} columns={COLUMNS} tablename={"emp-table"}filename={"BusinessError"}/>
          )}
        </div>
      </div>
    </>
  );
};
