import { React, useState, useLayoutEffect } from "react";
import { BusinessErrorPage } from "pages/reports/businesserror/BusinessErrorPage";
import PrimarySearchAppBar from "components/appbar/AppBarWithSideNav";
import { Button } from "components/button/Button";

export const BusinessErrorPageReport = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
        <div>
          <PrimarySearchAppBar user={user} email={email} />
          <BusinessErrorPage />
        </div>
      {/* )} */}
    </>
  );
};
