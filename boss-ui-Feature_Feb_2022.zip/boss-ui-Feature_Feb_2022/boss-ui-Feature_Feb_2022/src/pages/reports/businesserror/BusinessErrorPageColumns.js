export const COLUMNS = [
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "DocInfo",
    accessor: "docInfo",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "GPO",
    accessor: "gpo",
  },
  {
    Header: "VPO",
    accessor: "vpo",
  },
  {
    Header: "SalesOrderNo",
    accessor: "salesOrderNo",
  },
  {
    Header: "TieNumber",
    accessor: "tieNumber",
  }
  	  
];
