import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/voidelayhistory/VoiDelayHistory.css";
import VoiDelayHistoryProperties from "pages/reports/voidelayhistory/VoiDelayHistoryProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/voidelayhistory/VoiDelayHistoryColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";

export const VoiDelayHistory = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [voiDelayHistoryData, setVoiDelayHistoryData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  
 
  const [region, setRegion] = useState("");
  
  const [serviceTag, setServiceTag] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);



  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setVoiDelayHistoryData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = moment.utc(toDate);
      fromDateFormat = moment.utc(fromDate);
    }

    const data = {
      
      //endCreationDate: endCreationDate,
      //beginCreationDate: beginCreationDate,
      demandRegion: region,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data,"this is data");
    let url;

    if (reqRegion === "dao") {
      url = VoiDelayHistoryProperties.poSummaryDAO;
    } else {
      url = VoiDelayHistoryProperties.poSummaryEMEA;
    }

    console.log(JSON.stringify(data),"stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
       // setPoSummaryData(data);
        console.log(data,"returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false);
    
    setRegion("");
    
    setServiceTag("");
    
    checked.checkedB = false;
    setCheckedSvcTag(false);
    setVoiDelayHistoryData(null);
  };



  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">VOI Delay History report</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                 
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                 
                 
                </ul>
              </div>
              
              <div className="formcards__wrapper_row3">
                <ul className="formcards__items">



<div className="component_from_date_asnsummary">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        // value={beginCreationDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_asnsummary">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                        //  value={endCreationDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_asnsummary">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                  
                  
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                

                       {/* //insert componrnt here */}

                </ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-voidelay"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-voidelay"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                  {/* <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={handleReset}
                    >
                      Export to excel
                    </button>
                  </div> */}
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
        <div className="time_div">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}

          {setVoiDelayHistoryData && (
            <label className="rows" >
              Rows : {rows}
            </label>
          )}

          {setVoiDelayHistoryData && (
            <label className="rows" htmlFor="text">
              Time : {time}ms
            </label>
          )}
        </div>
        <div className="result__wrapper">
          {setVoiDelayHistoryData && (
            <BasicTable tdata={setVoiDelayHistoryData} columns={COLUMNS} tablename={"emp-table"}filename={"VoiDelayHistory"}/>
          )}
        </div>
      </div>
    </>
  );
};
