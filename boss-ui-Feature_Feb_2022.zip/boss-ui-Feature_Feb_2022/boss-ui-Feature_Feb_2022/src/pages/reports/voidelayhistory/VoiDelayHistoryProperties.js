const VoiDelayHistoryProperties =  {
  region: ["DAO", "EMEA", "APJ"],
  ordertype:["BTS","CTO","PLB","PLP","PLS","PLT","RTL","FGA","ALL"],

  getVendorListEMEA:
    "https://getvendors-ge2-emea.ausvtc01.pcf.dell.com/getVendors",
  getVendorListDAO:
    "https://getvendors-ge2-dao.ausvtc01.pcf.dell.com/getVendors",

  getOrderTypeEMEA:
    "https://po-service-ge2-dao.ausvtc01.pcf.dell.com/getordertypes",
  getOrderTypeDAO:
    "https://po-service-ge2-dao.ausvtc01.pcf.dell.com/getordertypes",

  getLocationNumberEMEA:
  "https://po-service-ge2-emea.ausvtc01.pcf.dell.com/getlocationnumbers",
  getLocationNumberDAO:
    "https://po-service-ge2-dao.ausvtc01.pcf.dell.com/getlocationnumbers",

  getCompanyNumberEMEA:
    "https://po-service-ge2-emea.ausvtc01.pcf.dell.com/getcompanynumbers",
  getCompanyNumberDAO:
    "https://po-service-ge2-dao.ausvtc01.pcf.dell.com/getcompanynumbers",

  getCurrentStatusEMEA:
    "https://po-service-ge2-emea.ausvtc01.pcf.dell.com/getorderstatuses",
  getCurrentStatusDAO:
    "https://po-service-ge2-emea.ausvtc01.pcf.dell.com/getorderstatuses",


  poSummaryDAO:
    "https://po-service-ge2-dao.ausvtc01.pcf.dell.com/getproductionorders",
  poSummaryEMEA:
    "https://po-service-ge2-emea.ausvtc01.pcf.dell.com/getproductionorders",
 
};
export default VoiDelayHistoryProperties;
