
export const COLUMNS = [
  {
    Header: "Vendor",
    accessor: "vendor",
  
  },
  {
    Header: "Doc Info",
    accessor: "docInfo",
  },
  {
    Header: "Reject Code",
    accessor: "rejectCode",
  },
  {
    Header: "Reject Reason",
    accessor: "rejectReason",
  },
  {
    Header: "Reject Detail",
    accessor: "rejectDetail",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "GPO",
    accessor: "gpo",
  },
  {
    Header: "VPO",
    accessor: "vpo",
  },
  {
    Header: "Sales Order Number",
    accessor: "salesOrderNo",
  }, 

  {
    Header: "Tie Number",
    accessor: "tieNumber",
  },
  {
    Header: "Demand Region",
    accessor: "demandRegion",
  },
  {
    Header: "SSC",
    accessor: "ssc",
  },
  {
    Header: "Family",
    accessor: "family",
  },
  {
    Header: "Model",
    accessor: "model",
  },
  {
    Header: "OS Token Type",
    accessor: "osTokenType",
  },
  {
    Header: "OS Lanuage",
    accessor: "osLanguage",
  },
  {
    Header: "Parts",
    accessor: "parts",
  },
  {
    Header: "Doc Type",
    accessor: "docType",
  },
  {
    Header: "ASN Number",
    accessor: "asnNumber",
  },
  {
    Header: "Error code",
    accessor: "errorCode",
  },
  {
    Header: "Document ID",
    accessor: "SdocumentID",
  },
];
