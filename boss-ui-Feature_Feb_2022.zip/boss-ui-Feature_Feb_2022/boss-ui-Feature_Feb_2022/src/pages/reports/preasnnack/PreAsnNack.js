import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/preasnnack/PreAsnNack.css";
import PreAsnNackProperties from "pages/reports/preasnnack/PreAsnNackProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/preasnnack/PreAsnNackColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";

export const PreAsnNack = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [preAsnNackData, setPreAsnNackData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [salesOrder, setSalesOrder] = useState("");
  const [region, setRegion] = useState("");
  
  const [asnNumber, setAsnNumber] = useState("");
  const [serviceTag, setServiceTag] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);

  const [vendor, setVendor] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState("");



  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setPreAsnNackData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = dateFormat(toDate, "yyyy-mm-dd HH:MM:ss");
      fromDateFormat = dateFormat(fromDate, "yyyy-mm-dd HH:MM:ss");
    }

    const data = {
      vendor: selectedVendor,
      asnNumber:asnNumber,
      fromDate: fromDateFormat,
      toDate: toDateFormat,
      demandRegion: region,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data,"this is data");
    let url;

    if (reqRegion === "dao") {
      url = PreAsnNackProperties.poSummaryDAO;
    } else {
      url = PreAsnNackProperties.poSummaryEMEA;
    }

    console.log(JSON.stringify(data),"stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setPreAsnNackData(data);
        console.log(data,"returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };

  const sendDataToParent = (name, value) => {
    if (name === "Vendor") {
      setSelectedVendor(value);
    }  
    else if (name === "DemandRegion") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false);
    setAsnNumber("");
    setRegion("");
    setSelectedVendor("");
    setServiceTag("");
    checked.checkedB = false;
    setCheckedSvcTag(false);
    setPreAsnNackData(null);
  };

  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = PreAsnNackProperties.getVendorListDAO;
    } else {
      url = PreAsnNackProperties.getVendorListEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          arr.push(item.vendorName);
        });

        setVendor(arr);
      });
  }, []);


  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">PREASN NACK Page</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="component_preasn">
                  <label>
                      <Dropdown
                        name={"Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                        value={selectedVendor}
                      />
                    </label>
                  </div>
                  
                  <div className="component_preasn">
                    <TextInput
                      name="ASN Number"
                      onChange={(e) => setAsnNumber(e.target.value)}
                      value={asnNumber}
                      disabled={checkedSvcTag}
                    />
                  </div>
                 
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                 
                 
                 
                </ul>
              </div>
              
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  
                                     
                  
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                <div className="component_from_date_asnsummary">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_asnsummary">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_asnsummary">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                </ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_oppfailed"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_oppfailed"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                  {/* <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={handleReset}
                    >
                      Export to excel
                    </button>
                  </div> */}
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}

          {asnNumber && (
            <BasicTable tdata={asnNumber} columns={COLUMNS} tablename={"emp-table"}filename={"PreAsnNack"} rows={rows} time={time}/>
          )}
        </div>
      </div>
    </>
  );
};
