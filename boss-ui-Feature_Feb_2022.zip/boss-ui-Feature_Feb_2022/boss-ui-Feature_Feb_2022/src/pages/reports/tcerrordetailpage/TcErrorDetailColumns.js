
export const COLUMNS = [
    
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "Reject Code",
    accessor: "rejectCode",
  },
  {
    Header: "Reject Reason",
    accessor: "rejectReason",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "VPO",
    accessor: "vpo",
  },
  {
    Header: "GPO",
    accessor: "gpo",
  },
  {
    Header: "Sales Order No ",
    accessor: "salesOrderNo",
  }
];
