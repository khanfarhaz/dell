const TcErrorDetailProperties =  {
  getVendorListEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
getVendorListDAO:
  "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",

  poSummaryDAO:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/gettcerror",
  poSummaryEMEA:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/gettcerror",
 
};
export default TcErrorDetailProperties;
