import { React, useState, useLayoutEffect } from "react";
import { AsnNack } from "pages/reports/asnnack/AsnNack";
import PrimarySearchAppBar from "components/appbar/AppBarWithSideNav";
import { Button } from "components/button/Button";

export const AsnNackReport = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
        <div>
          <PrimarySearchAppBar user={user} email={email} />
          <AsnNack />
        </div>
      {/* )} */}
    </>
  );
};
