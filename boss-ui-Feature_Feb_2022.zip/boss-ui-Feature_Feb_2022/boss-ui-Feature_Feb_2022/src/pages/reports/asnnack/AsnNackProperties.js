const AsnNackProperties =  {
  getVendorListEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
getVendorListDAO:
  "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",


  poSummaryDAO:
    "https://po-service-ge2-dao.ausvtc01.pcf.dell.com/getasnnack",
  poSummaryEMEA:
    "https://po-service-ge2-emea.ausvtc01.pcf.dell.com/getasnnack",
 
};
export default AsnNackProperties