
export const COLUMNS = [    			
  
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "	Reject Code",
    accessor: "rejectCode",
  },
  {
    Header: "Reject Reason",
    accessor: "rejectReason",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "Demand Region",
    accessor: "demandregion",
  },
  {
    Header: "ASN Number",
    accessor: "asnNumber",
  },
 
];
