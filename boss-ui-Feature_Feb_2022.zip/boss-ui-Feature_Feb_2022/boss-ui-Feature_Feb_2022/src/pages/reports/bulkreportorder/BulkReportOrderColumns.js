
export const COLUMNS = [
  {
    Header: "Sales Order",
    accessor: "salesOrder",
    // Cell: (e) => (
    //   <a
    //     href={`po-detail?salesOrder=${e.value}`}
    //     target="_blank"
    //     rel="noopener noreferrer"
    //   >
    //     {e.value}
    //   </a>
    // ),
  },
  {
    Header: "EMC PO",
    accessor: "emcPO",
  },
  {
    Header: "EMC SO",
    accessor: "emcSO",
  },
        
  {
    Header: "Demand Region",
    accessor: "demandRegion",
  },
  {
    Header: "Order tie",
    accessor: "orderTie",
  },
  {
    Header: "IP Order Date",
    accessor: "ipOrderDate",
  },
  {
    Header: "Production Order",
    accessor: "productionOrder",
    Cell: (e) => (
      <a
        href={`po-detail?productionOrder=${e.value}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        {e.value}
      </a>
    ),
  },
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "Vendor Work Order",
    accessor: "vendorWorkOrderId",
    Cell: (e) => (
      <a
        href={`po-detail?vendorWorkOrder=${e.value}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        {e.value}
      </a>
    ),
    
  },
  
  {
    Header: "Date Created",
    accessor: "createdDate",
  },
  {
    Header: "Blanket PO",
    accessor: "blanketPO",
  },
  {
    Header: "Actual PO",
    accessor: "actualPO",
  },
  {
    Header: "Family/Base type",
    accessor: "familyBaseType",
  },
  {
    Header: "Order Type",
    accessor: "orderType",
  },
  {
    Header: "SSC Type",
    accessor: "sscType",
  },
  {
    Header: "Quantity",
    accessor: "quantity",
  },
  {
    Header: "MCID",
    accessor: "mcid",
  },
  {
    Header: "OPP NACK",
    accessor: "oppNack",
  },
  {
    Header: "Status Time Stamp",
    accessor: "statusTimestamp",
  },
  {
    Header: "Previous Status",
    accessor: "previousStatus",
  },
  {
    Header: "Current Status",
    accessor: "currentStatus",
  },
  {
    Header: "CO Num",
    accessor: "coNum",
  },

  {
    Header: "LOC Num",
    accessor: "locNum",
  },
  {
    Header: "Service Tag",
    accessor: "serviceTag",
  },
  {
    Header: "RDD STATUS",
    accessor: "rddStatus",
  },
  {
    Header: "REVISED DELIVERY DATE",
    accessor: "revisedDeliveryDate",
  },
  {
    Header: "REVISED SHIP DATE",
    accessor: "revisedShipDate",
  },
  {
    Header: "RSD REVISION COUNT",
    accessor: "rsdRevisionCount",
  }
];
