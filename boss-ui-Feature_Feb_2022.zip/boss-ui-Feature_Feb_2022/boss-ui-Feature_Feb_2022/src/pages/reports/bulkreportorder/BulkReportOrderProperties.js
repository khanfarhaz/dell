const BulkReportOrderProperties =  {

  bulkOrderDAO:
    "https://bulkorder-ui-dao-ge2.pnp3.pcf.dell.com/getbulkorderdetails",
    bulkOrderEMEA:
    "https://bulkorder-ui-emea-ge2.pnp3.pcf.dell.com/getbulkorderdetails",
 
};
export default BulkReportOrderProperties;
