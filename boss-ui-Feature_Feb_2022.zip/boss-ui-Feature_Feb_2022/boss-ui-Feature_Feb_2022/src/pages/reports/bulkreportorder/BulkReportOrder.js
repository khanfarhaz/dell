import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/bulkreportorder/BulkReportOrder.css";
import BulkReportOrderProperties from "pages/reports/bulkreportorder/BulkReportOrderProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/bulkreportorder/BulkReportOrderColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";
//import TextareaAutosize from '@bit/mui-org.material-ui.textarea-autosize';
import Textfield from '@material-ui/core/textfield'
import TextareaAutosize from '@mui/material/TextareaAutosize'
import { BulkReportOrderReport } from "./BulkReportOrderReport";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
//import BulkReportOrderProperties from "./BulkReportOrderProperties";

export const BulkReportOrder = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  // const handleChange = (event) => {
  //   setChecked({ ...checked, [event.target.name]: event.target.checked });
  // };

  const handleChange = (event) => {
    setType(event.target.value);
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [vendorWorkorderData, setVendorWorkorderData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const [typess, setType] = useState("");
  const [valuess, setValues] = useState("");
  const [region, setRegion] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);
 
  
  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setVendorWorkorderData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = moment.utc(toDate);
      fromDateFormat = moment.utc(fromDate);
    }

    const data = {
      type:typess,
      values:valuess,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data,"this is data");
    let url;

    if (reqRegion === "dao") {
      url = BulkReportOrderProperties.bulkOrderDAO;
    } else {
      url = BulkReportOrderProperties.bulkOrderEMEA;
    }

    console.log(JSON.stringify(data),"stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setVendorWorkorderData(data);
        console.log(data,"returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };


  const handleReset = () => {
  
    setIsLoading(false);
    setType("");
    setValues("");
    setRegion("");
    checked.checkedB = false;
    setVendorWorkorderData(null);
  };


  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">Bulk Report Order Page</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                <div className="dropdown_component">
                    <label>
                      
    <FormControl sx={{ m: 0, minWidth: 165,marginTop:2,fontSize:0 }}>
        <InputLabel id="demo-simple-select-helper-label">Sales order ID(s)</InputLabel>
        <Select
          // labelId="demo-simple-select-helper-label"
          id="demo-simple-select-helper"
          value={typess}
          label="Sales order ID(s)"
          onChange={handleChange}
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={0}>Sales order ID(s)</MenuItem>
          <MenuItem value={1}>Production Order Number(s)</MenuItem>
          <MenuItem value={2}>Vendor Work Order ID(s)</MenuItem>
          <MenuItem value={3}>Service Tag(s)</MenuItem>
          <MenuItem value={4}>Agreement ID(s)</MenuItem>
        </Select>
        
      </FormControl>
                    </label>
                  </div>
                 
                </ul>
              </div>

              <div className="formcards__wrapper_row3">
                <ul className="formcards__items">
                  
                <div className="narrativebulkorder">
                  <h5>Enter up to 500 Order Values. Order Values may be EITHER comma seperated or space seperated, ie: '123456789,123456789,...' or '123456789 123456789 ...'</h5>
                  </div>
    
                  
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  
                   <TextareaAutosize
                    rowsMin={100}
                    placeholder=''
                    defaultValue=''
                    // name="MCID"
                    onChange={(e) => setValues(e.target.value)}
                    value={valuess}
                    style={{ width: "200%",
                    height: 180,
                    margin:10                                 
                     }} />
                </ul>
                <ul className="formcards__items">
                  <div className="component_search_bulk">
                    <button
                      type="button"
                      className="btnnew-onhold_asnsummary"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search_bulk">
                    <button
                      type="button"
                      className="btnnew-onhold_asnsummary"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                  
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}
 
          {vendorWorkorderData && (
            <BasicTable tdata={vendorWorkorderData} columns={COLUMNS} tablename={"emp-table"} filename={"BulkOrderReport"} rows={rows} time={time}/>
          )}
        </div>
      </div>
    </>
  );
};

