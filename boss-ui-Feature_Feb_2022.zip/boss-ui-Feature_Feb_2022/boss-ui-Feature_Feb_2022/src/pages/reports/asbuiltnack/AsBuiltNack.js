import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/asbuiltnack/AsBuiltNack.css";
import AsBuiltNackProperties from "pages/reports/asbuiltnack/AsBuiltNackProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/asbuiltnack/AsBuiltNackColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";
//import TextareaAutosize from '@bit/mui-org.material-ui.textarea-autosize';
import Textfield from '@material-ui/core/textfield'
import TextareaAutosize from '@mui/material/TextareaAutosize'
import { BAsBuiltNackReport } from "./AsBuiltNackReport";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
//import BulkReportOrderProperties from "./BulkReportOrderProperties";

export const AsBuiltNack = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [vendorWorkorderData, setVendorWorkorderData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const [typess, setType] = useState("");
  const [valuess, setValues] = useState("");
  const [documentID, setDocumentID] = useState("");
  const [region, setRegion] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);
  const [vendor, setVendor] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState("");
 

  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setVendorWorkorderData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = moment.utc(toDate);
      fromDateFormat = moment.utc(fromDate);
    }

    const data = {
      type:typess,
      values:valuess,
      region: reqRegion.toUpperCase(),
      vendor: selectedVendor,
      documentID:documentID,
      fromDate: fromDateFormat,
      toDate: toDateFormat
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data,"this is data");
    let url;

    if (reqRegion === "dao") {
      url = AsBuiltNackProperties.poSummaryDAO;
    } else {
      url = AsBuiltNackProperties.poSummaryEMEA;
    }

    console.log(JSON.stringify(data),"stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setVendorWorkorderData(data);
        console.log(data,"returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };

  const sendDataToParent = (name, value) => {
    if (name === "Vendor") {
      setSelectedVendor(value);
    }
    else if (name === "DemandRegion") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    
    setIsLoading(false);
    setType("");
    setValues("");
    setRegion("");
    setSelectedVendor("");
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    checked.checkedB = false;
    setVendorWorkorderData(null);
  };
  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = AsBuiltNackProperties.getVendorListDAO;
    } else {
      url = AsBuiltNackProperties.getVendorListEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          arr.push(item.vendorName);
        });

        setVendor(arr);
      });
  }, []);
 

  return (
    <>
      <div>
        <div className="uIformcards_asbuilt">
          <div className="uIformcards__container_asbuilt">
            <div className="narrative_asbuilt"> As Built Nack Page</div>
            <form id="on-hold-form_asbuilt">
              
              <div className="formcards__wrapper_asbuilt">
                <ul className="formcards__items_asbuilt">

                    <div className="dropdown_component_asbuilt">
                        <label>
                                <FormControl sx={{ m: 0, minWidth: 165,marginTop:0,fontSize:0 }}>
                                  <div className="dropdown_component_asbuilt">
                                    <label>
                                      <Dropdown
                                        name={"Vendor"}
                                        listItems={vendor}
                                        sendDataToParent={sendDataToParent}
                                        value={selectedVendor}
                                      />
                                    </label>
                                </div>
                                </FormControl>
                        </label>
                      </div>  

                </ul>
              </div>

              <div className="formcards__wrapper_row_asbuilt">
                <ul className="formcards__items_asbuilt">
                
                 
                </ul>
              </div>
              
              <div className="formcards__wrapper_row3_asbuilt">
                <ul className="formcards__items_asbuilt">
                  
                <div className="narrativebulkorder_asbuilt">
                  <h5>	Enter up to 999 Order Values. Document Id's may be EITHER comma seperated or space seperated, ie: '123456789,123456789,...' or '123456789 123456789 ...'</h5>
                  </div>
                </ul>
              </div>

              <div className="formcards__wrapper_row_asbuilt">
                <ul className="formcards__items_asbuilt">
                  
                   <TextareaAutosize
                    rowsMin={100}
                    placeholder=''
                    defaultValue=''
                    // name="MCID"
                    onChange={(e) => setDocumentID(e.target.value)}
                    value={documentID}
                    style={{ width: "200%",
                    height: 180,
                    margin:10                                 
                     }} />
                </ul>


                <div className="formcards__wrapper_row3_asbuilt">
                <ul className="formcards__items_asbuilt">
                  
                 <div className="component_from_date_asnsummary_asbuilt">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_asnsummary_asbuilt">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_asnsummary_asbuilt">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div> 
                   
                  
                </ul>
              </div>
                <ul className="formcards__items_asbuilt">
                  <div className="component_search_bulk_asbuilt">
                    <button
                      type="button"
                      className="btnnew-onhold_asnsummary_asbuilt"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search_bulk_asbuilt">
                    <button
                      type="button"
                      className="btnnew-onhold_asnsummary_asbuilt"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
        
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container_asbuilt">
      <div className="result__wrapper_asbuilt">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}
          {vendorWorkorderData && (
            <BasicTable tdata={vendorWorkorderData} columns={COLUMNS} tablename={"emp-table"} filename={"AsBuiltNack"} rows={rows} time={time}/>
          )}
        </div>
      </div>
    </>
  );
};



