
export const COLUMNS = [
    				
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "Reject Code",
    accessor: "",
  },
        
  {
    Header: "Reject Reason",
    accessor: "rejectCode",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "Document ID",
    accessor: "documentID",
  }
];
