const AsBuiltNackProperties =  {

  getVendorListEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
getVendorListDAO:
  "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",

  poSummaryDAO:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/getasbuiltnack",
  poSummaryEMEA:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/getasbuiltnack",
 
};
export default AsBuiltNackProperties;
