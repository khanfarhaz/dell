
export const COLUMNS = [

  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "Reject Code",
    accessor: "rejectCode",
  },
  {
    Header: "Reject Reason",
    accessor: "rejectReason",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "GPO",
    accessor: "gpo",
  },
  {
    Header: "VPO",
    accessor: "vpo",
  },
  {
    Header: "Sales Order No",
    accessor: "salesOrderNo",
  },
  {
    Header: "Demand Region",
    accessor: "demandRegion",
  },
 {
    Header: "Parts",
    accessor: "osTokenType",
  },

  {
    Header: "Order Tie",
    accessor: "tieNumber",
  }
];
