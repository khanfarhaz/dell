const VendorPoNackProperties =  {
  region: ["DAO", "EMEA", "APJ"],
  ordertype:["BTS","CTO","PLB","PLP","PLS","PLT","RTL","FGA","ALL"],

  getVendorListEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
getVendorListDAO:
  "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",

    vendorPoNackDAO:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/getvendorpurchaseordernacks",
    vendorPoNackEMEA:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/getvendorpurchaseordernacks",
 
};
export default VendorPoNackProperties;
