import { React, useState, useLayoutEffect } from "react";
import PrimarySearchAppBar from "components/appbar/AppBarWithSideNav";
import { AsnDetailForm } from "pages/reports/asndetail/AsnDetailForm";

export const AsnDetailReport = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
      <div>
        <PrimarySearchAppBar user={user} email={email} />
        <AsnDetailForm />
      </div>
      ;{/* )} */}
    </>
  );
};
