const AsnDetailProperties = {
  // getAsnDetailSummaryDAO:
  //   "https://asndetail-service-ge2-dao.ausvtc01.pcf.dell.com/getasndetailsummary",
  // getAsnDetailSummaryEMEA:
  //   "https://asndetail-service-ge2-emea.ausvtc01.pcf.dell.com/getasndetailsummary",
  // getAsnSubItemDao:
  //   "https://asndetail-service-ge2-dao.ausvtc01.pcf.dell.com/getsublineitem",
  // getAsnSubItemEmea:
  //   "https://asndetail-service-ge2-emea.ausvtc01.pcf.dell.com/getsublineitem",
  // getAsnDetailPartsDao:
  //   "https://asndetail-service-ge2-dao.ausvtc01.pcf.dell.com/getasndetailpart",
  // getAsnDetailPartsEmea:
  //   "https://asndetail-service-ge2-emea.ausvtc01.pcf.dell.com/getasndetailpart",

  getAsnDetailSummaryDAO:
    "https://asndetail-ui-dao-ge2.pnp3.pcf.dell.com/getasndetailsummary",
  getAsnDetailSummaryEMEA:
    "https://asndetail-ui-emea-ge2.pnp3.pcf.dell.com/getasndetailsummary",
  getAsnSubItemDao:
    "https://asndetail-ui-dao-ge2.pnp3.pcf.dell.com/getsublineitem",
  getAsnSubItemEmea:
    "https://asndetail-ui-emea-ge2.pnp3.pcf.dell.com/getsublineitem",
  getAsnDetailPartsDao:
    "https://asndetail-ui-dao-ge2.pnp3.pcf.dell.com/getasndetailpart",
  getAsnDetailPartsEmea:
    "https://asndetail-ui-emea-ge2.pnp3.pcf.dell.com/getasndetailpart"
};


export default AsnDetailProperties;
