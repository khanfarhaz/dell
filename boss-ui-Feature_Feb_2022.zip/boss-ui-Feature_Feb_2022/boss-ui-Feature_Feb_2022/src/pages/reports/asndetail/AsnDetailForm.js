import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/asndetail/AsnDetail.css";
import AsnDetailProperties from "pages/reports/asndetail/AsnDetailProperties";
import { AsnSubDetailPartDetailColumns } from "pages/reports/asndetail/AsnSubDetailPartColumns";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { ExportToExcel } from "components/exporttoexcel/ExportToExcel";
import exportFromJSON from 'export-from-json' ;
import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";

export const AsnDetailForm = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [asnNum, setAsnNum] = useState("");
  const [checkedSvcTag, setCheckedSvcTag] = useState(false);
  const [asnDetailData, setAsnDetailData] = useState(null);
  const [asnSubLineItem, setAsnSubLineItem] = useState(null);
  const [asnDetailPart, setAsnDetailPart] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingLineItem, setIsLoadingLineItem] = useState(false);
  const [isLoadingDetailPart, setIsLoadingDetailPart] = useState(false);
  const [salesOrder, setSalesOrder] = useState("");
  const [hawbNumber, setHawbNumber] = useState("");
  const [asnNumParam, setAsnNumParam] = useState("");
  const [agreementId, setAgreementId] = useState("");
  const [mergeCenterId, setMergeCenterId] = useState("");
  const [rows, setRows] = useState(0);
  const [rowsSubLineItem, setRowsSubLineItem] = useState(0);
  const [rowsDetailPart, setRowsDetailPart] = useState(0);
  const [time, setTime] = useState(0);
  const [timeSubLineItem, setTimeSubLineItem] = useState(0);
  const [timeDetailPart, setTimeDetailPart] = useState(0);
  const [serviceTag, setServiceTag] = useState("");
  const [manifestId, setManifestId] = useState("");

  const fileName = 'download'  
const exportType = 'xls'
const fileExtension = ".xlsx";
const fileType =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";

  const getSublineItem = (palletId) => {
    setAsnDetailPart(null);
    setAsnSubLineItem(null);
    console.log(palletId);
    const start = new Date(); //to time the service call
    setIsLoadingLineItem(true);

    const data = {
      asnPalletId: palletId,
      region: reqRegion.toUpperCase(),
    };

    let url;

    if (reqRegion === "dao") {
      url = AsnDetailProperties.getAsnSubItemDao;
    } else {
      url = AsnDetailProperties.getAsnSubItemEmea;
    }

    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRowsSubLineItem(data.length);
        setAsnSubLineItem(data);
        console.log(data);
        setIsLoadingLineItem(false);
        setTimeSubLineItem(new Date() - start); //total time
      });
  };

  const AsnDetailColumns = [
    {
      Header: " ",
      accessor: "asnPalletId",
      Cell: (e) => (
        <a href="#/" onClick={() => getSublineItem(e.value)}>
          View Line Item Detail
        </a>
      ),
    },
    {
      Header: "ASN Num",
      accessor: "asnNum",
    },
    {
      Header: "Manifest ID",
      accessor: "manifestId",
    },
    {
      Header: "Pallet Id",
      accessor: "palletId",
    },
    {
      Header: "Pallet Seq",
      accessor: "palletNum",
    },
    {
      Header: "Pallet Total",
      accessor: "palletTotal",
    },
  ];

  const getDetailParts = (palletId) => {
    setAsnDetailPart(null);

    const start = new Date(); //to time the service call
    setIsLoadingDetailPart(true);

    const data = {
      asnPalletId: palletId,
      region: reqRegion.toUpperCase(),
    };

    let url;

    if (reqRegion === "dao") {
      url = AsnDetailProperties.getAsnDetailPartsDao;
    } else {
      url = AsnDetailProperties.getAsnDetailPartsEmea;
    }

    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRowsDetailPart(data.length);
        setAsnDetailPart(data);
        // console.log(data);
        setIsLoadingDetailPart(false);
        setTimeDetailPart(new Date() - start); //total time
      });
  };

  const AsnSublineItemColumns = [
    {
      Header: " ",
      accessor: "asnItemIid",
      Cell: (e) => (
        <a href="#/" onClick={() => getDetailParts(e.value)}>
          SubLine Items Detail
        </a>
      ),
    },
    {
      Header: "Line Item",
      accessor: "lineItem",
    },
    {
      Header: "PO",
      accessor: "po",
    },
    {
      Header: "PO Qty",
      accessor: "poQty",
    },
    {
      Header: "Tie Group",
      accessor: "tieGroup",
    },
    {
      Header: "Sales Order Id",
      accessor: "salesOrderNum",
    },
    {
      Header: "Prod Order #",
      accessor: "prodOrderNum",
    },
    {
      Header: "Vendor Work Order Id",
      accessor: "vendorWorkOrderId",
    },
    {
      Header: "Demand Region",
      accessor: "region",
    },
    {
      Header: "Service Tag",
      accessor: "serviceTag",
    },
    {
      Header: "IS_System",
      accessor: "isSystem",
    },
    {
      Header: "Chassis PPID",
      accessor: "chassisppid",
    },
    ,
    {
      Header: "FGA Part Num",
      accessor: "fgaPartNum",
    },
    ,
    {
      Header: "KMP Part Num",
      accessor: "kmpPartNum",
    },
  ];

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  useLayoutEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const asnParam = queryParams.get("asn");
    console.log(asnParam);
    if (asnParam != null && asnParam != "") {
      const start = new Date(); //to time the service call
      setIsLoading(true);
      setAsnDetailData(null);
      setAsnNum(asnParam);
      const data = {
        asnNum: asnParam,
        region: reqRegion.toUpperCase(),
      };

      let url;

      if (reqRegion === "dao") {
        url = AsnDetailProperties.getAsnDetailSummaryDAO;
      } else {
        url = AsnDetailProperties.getAsnDetailSummaryEMEA;
      }

      fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setRows(data.length);
          setAsnDetailData(data);
          setIsLoading(false);
          setTime(new Date() - start); //total time
        });
    }
  }, []);

  const handleSearch = () => {
    const start = new Date(); //to time the service call
    setIsLoading(true);
    setAsnDetailData(null);
    setAsnSubLineItem(null);
    setAsnDetailPart(null);

    
    const data = {
      salesOrderNum: salesOrder,
      hawbNum: hawbNumber,
      asnNum: asnNum,
      agreementId: agreementId,
      mergeCenterId: mergeCenterId,
      manifestId: manifestId,
      serviceTag: serviceTag,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    // console.log(data);
    let url;

    if (reqRegion === "dao") {
      url = AsnDetailProperties.getAsnDetailSummaryDAO;
    } else {
      url = AsnDetailProperties.getAsnDetailSummaryEMEA;
    }

    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setAsnDetailData(data);
        // console.log(data);
        setIsLoading(false);
        setTime(new Date() - start); //total time
      });
  };

  const handleReset = () => {
    setIsLoading(false);
    setSalesOrder("");
    setHawbNumber("");
    setAsnNum("");
    setAgreementId("");
    setMergeCenterId("");
    setServiceTag("");
    setCheckedSvcTag(false);
    setAsnDetailData(null);
  };

  const showLineItemDetail = (value) => {
    alert(value);
  };

  var data1 = asnDetailData;
    var data2 = asnDetailPart;
    var data3 = asnSubLineItem;
    var concatdata=[];
    concatdata.push(data1);
    concatdata.push(data2);
    concatdata.push(data3);
 

  const exportToCSV = (apiData, fileName) => {
    const wb = {SheetNames:[], Sheets: {} };
    var ws1 = XLSX.utils.json_to_sheet(apiData[0]);
    var ws2 = XLSX.utils.json_to_sheet(apiData[1]);
    var ws3 = XLSX.utils.json_to_sheet(apiData[2]);

    wb.SheetNames.push("ASN Detail"); wb.Sheets["ASN Detail"]=ws1
    wb.SheetNames.push("ASN Subline item"); wb.Sheets["ASN Subline item"]=ws2
    wb.SheetNames.push("ASN Detail parts"); wb.Sheets["ASN Detail parts"]=ws3

    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: fileType });
    FileSaver.saveAs(data, fileName + fileExtension);
  };




  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">Advance Ship Notice Detail</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="Sales Order"
                      onChange={(e) => setSalesOrder(e.target.value)}
                      value={salesOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Hawb Number"
                      onChange={(e) => setHawbNumber(e.target.value)}
                      value={hawbNumber}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Asn Num"
                      onChange={(e) => setAsnNum(e.target.value)}
                      value={asnNum}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Manifest Id"
                      onChange={(e) => setManifestId(e.target.value)}
                      value={manifestId}
                      disabled={checkedSvcTag}
                    />
                  </div>
                </ul>
              </div>
              <div className="formcards__wrapper_row3">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="Merge Center ID"
                      onChange={(e) => setMergeCenterId(e.target.value)}
                      value={mergeCenterId}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  {reqRegion !== "dao" && (
                    <div className="component">
                      <TextInput
                        name="Agreement Id"
                        onChange={(e) => setAgreementId(e.target.value)}
                        value={agreementId}
                        disabled={checkedSvcTag}
                      />
                    </div>
                  )}
                  <div className="component">
                    <TextInput
                      name="Service Tag"
                      onChange={(e) => setServiceTag(e.target.value)}
                      value={serviceTag}
                      disabled={!checkedSvcTag}
                    />
                  </div>
                  <div className="checkbox_svctag">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkedSvcTag}
                          onChange={handleChangeSvcTag}
                          name="checkedSvcTag"
                          color="primary"
                        />
                      }
                      label="Svc Tag"
                    />
                  </div>
                </ul>
              </div>
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  <div className="component_search_asndetail">
                    <button
                      type="button"
                      className="btnnew-onhold_asndetail"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search_asndetail">
                    <button
                      type="button"
                      className="btnnew-onhold_asndetail"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>

                  {/* <div className="component_search_asndetail">
                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={(e) => ExportToExcel(concatdata, "anusha")}
                    >
                      Export all
                    </button>
                  </div> */}
                  
                  <div className="component_search_asndetail">
                    <div className="onhold_asndetail">
                  <ExportToExcel data1={asnDetailData} data2={asnDetailPart} data3={asnSubLineItem}
                   filename="ASN Detail report" sheet1="ASN Detail" sheet3="ASN Detail parts" sheet2="ASN Subline items"/>
                  </div>
                  </div>
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
        
        <div className="result__wrapper">
        <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}
          {asnDetailData && (
            <BasicTable tdata={asnDetailData} columns={AsnDetailColumns} tablename={"asn-summary"} rows={rows} time={time} filename={"AsnDetail"}/>
          )}
        </div>
        
        <div className="result__wrapper">
        {asnSubLineItem && <ColoredLine color="blue" />}

{isLoadingLineItem && <LoadingCircle />}
          {asnSubLineItem && (
            <BasicTable
              tdata={asnSubLineItem}
              columns={AsnSublineItemColumns}
              tablename={"asn-summary","asn-line-items"}
              rows={rowsSubLineItem} time={timeSubLineItem}
              filename={"AsnSubLineItem"}
            />
          )}
        </div>
        
        <div className="result__wrapper">
        {asnDetailPart && <ColoredLine color="blue" />}

{isLoadingDetailPart && <LoadingCircle />}
          {asnDetailPart && (
            <BasicTable
              tdata={asnDetailPart}
              columns={AsnSubDetailPartDetailColumns}
              tablename={"asn-subline-item"}
              rows={rowsDetailPart} time={timeDetailPart}
              filename={"AsnDetailPart"}
            />
          )}
        </div>
        
      </div>
    </>
  );
};
