export const COLUMNS = [
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "Delay Reason",
    accessor: "rejectCode",
  },
  {
    Header: "Reason Desc",
    accessor: "rejectReason",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "Production Order",
    accessor: "gpo",
  },
  {
    Header: "Vendor Work Order",
    accessor: "vpo",
  },
  {
    Header: "Demand Region",
    accessor: "demandRegion",
  },
  {
    Header: "SSC Type",
    accessor: "sscType",
  },
  {
    Header: "SalesOrderNo",
    accessor: "salesOrderNo",
  },
  {
    Header: "CompanyNum",
    accessor: "companyNum",
  },
  {
    Header: "LocationNum",
    accessor: "locationNum",
  },
];
