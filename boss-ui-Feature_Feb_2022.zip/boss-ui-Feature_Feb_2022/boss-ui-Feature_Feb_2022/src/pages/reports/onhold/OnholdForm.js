import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import dateFormat from "dateformat";
import "pages/reports/onhold/OnholdForm.css";
import OnHoldProperties from "pages/reports/onhold/OnHoldProperties";
import Dropdown from "components/dropdown/Dropdown";
import DateTimePicker from "react-datetime-picker";
import { makeStyles } from "@material-ui/core/styles";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextField from "@material-ui/core/TextField";

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(10),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

function OnholdForm() {
  const form = useRef(null);

  const classes = useStyles();
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];
  const [state, setState] = React.useState({
    isChecked: true,
  });
  const ColoredLine = ({ color }) => (
    <hr
      style={{
        color: color,
        backgroundColor: color,
        height: 2,
        borderColor: "#000000",
        width: 1000,
      }}
    />
  );
  const handleChange = (event) => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value,
    });
  };

  const [selectedVendor, setSelectedVendor] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [exportExcel, setExportExcel] = useState(false);
  const [salesOrder, setSalesOrder] = useState("");
  const [productOrder, setProductOrder] = useState("");
  const [workOrder, setWorkOrder] = useState("");
  const [vendor, setVendor] = useState([]);
  const [agreementId, setAgreementId] = useState("");
  const [locationNo, setLocationNo] = useState("");
  const [region, setRegion] = useState("");
  const [toDate, setToDate] = useState(new Date());
  const [fromDate, setFromDate] = useState(new Date());
  const [onHoldData, setonHoldData] = useState(null);

  const [valchecked, setradioinput] = useState(false);

  const inputchangehandler = () => {
    setradioinput((valchecked) => !valchecked);
  };

  useEffect(() => {
    // do stuff
    //alert(selectedVendor);
  }, [selectedVendor]);

  const handleSearch = () => {
    setIsLoading(true);
    setonHoldData(null);
    let toDateFormat = "";
    let fromDateFormat = "";
    if (valchecked === false) {
      toDateFormat = dateFormat(toDate, "yyyy-mm-dd HH:MM:ss");
      fromDateFormat = dateFormat(fromDate, "yyyy-mm-dd HH:MM:ss");
    }
    const data = {
      vendor: selectedVendor,
      salesOrder: salesOrder,
      productionOrder: productOrder,
      vendorWorkOrder: workOrder,
      //"agreementId":agreementId,
      //"locationNumber":locationNo
      // companyNumber: "sasas",
      fromDate: fromDateFormat,
      toDate: toDateFormat,
    };

    fetch(OnHoldProperties.onHoldService, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setonHoldData(data);
        setIsLoading(false);
      });
  };

  const sendDataToParent = (name, value) => {
    setSelectedVendor(value);
    //alert(value);
    //alert(selectedVendor);
  };
  const handleReset = () => {
    Array.from(document.querySelectorAll("input")).forEach(
      (input) => (input.value = "")
    );
  };

  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = OnHoldProperties.getVendorListDAO;
    } else {
      url = OnHoldProperties.getVendorListEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          arr.push(item.vendorName);
        });

        setVendor(arr);
      });
  }, []);

  const exportDataToExcel = () => {
    setExportExcel(true);
  };

  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">On Hold Report</div>

            <form id="on-hold-form" ref={form}>
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="component">
                    <label>
                      SalesOrder:
                      <input
                        type="text"
                        name="salesOrder"
                        placeholder="Sales Order"
                        value={salesOrder}
                        onChange={(e) => setSalesOrder(e.target.value)}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <input
                        type="text"
                        name="productOrder"
                        placeholder="Production Order"
                        value={productOrder}
                        onChange={(e) => setProductOrder(e.target.value)}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <input
                        type="text"
                        name="workOrder"
                        placeholder="Vendor Work Order"
                        value={workOrder}
                        onChange={(e) => setWorkOrder(e.target.value)}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        value={"Company No"}
                        listItems={OnHoldProperties.locationAndCompNum}
                      />
                    </label>
                  </div>
                </ul>
              </div>
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  {reqRegion !== "dao" && (
                    <div className="component">
                      <label>
                        <input
                          type="text"
                          name="agreementId"
                          placeholder="Agreement Id"
                          value={agreementId}
                          onChange={(e) => setAgreementId(e.target.value)}
                        />
                      </label>
                    </div>
                  )}
                  <div className="component">
                    <label>
                      <Dropdown
                        value={"Location no"}
                        listItems={OnHoldProperties.locationAndCompNum}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        value={"Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        value={"Region"}
                        listItems={OnHoldProperties.region}
                      />
                    </label>
                  </div>
                </ul>
              </div>

              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="date-component-onhold">
                    <label>
                      From:
                      <DateTimePicker
                        onChange={setFromDate}
                        value={fromDate}
                        disabled={valchecked}
                      />
                    </label>
                    <label>
                      To:
                      <DateTimePicker
                        onChange={setToDate}
                        value={toDate}
                        disabled={valchecked}
                      />
                    </label>
                    <label>
                      <input
                        type="checkbox"
                        value={valchecked}
                        name="date"
                        onChange={inputchangehandler}
                      />
                      Date
                    </label>
                  </div>
                </ul>

                <ul className="formcards__items">
                  <div className="date-component-onhold">
                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={handleSearch}
                    >
                      Search
                    </button>

                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={handleReset}
                    >
                      Reset
                    </button>

                    <button
                      className="btnnew-onhold"
                      type="button"
                      // onClick={exportDataToExcel}
                    >
                      Export
                    </button>
                    {/*
                    <FormControl className={classes.formControl}>
                      <InputLabel htmlFor="age-native-simple">
                        Current Page
                      </InputLabel>
                      <Select
                        native
                        value={state.age}
                        onChange={handleChange}
                        inputProps={{
                          name: "age",
                          id: "age-native-simple",
                        }}
                      >
                        <option aria-label="None" value="" />
                        <option value={10}>Current page</option>
                        <option value={20}>All pages</option>
                      </Select>
                      </FormControl> */}
                  </div>
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div>{/* <ColoredLine color="black" /> */}</div>
      <div id="onHoldData">
        {onHoldData && <BasicTable tdata={onHoldData} />}
        {isLoading && <LoadingCircle />}
      </div>
    </>
  );
}

export default OnholdForm;
