import { React, useState, useLayoutEffect } from "react";
import OnholdForm2 from "pages/reports/onhold/OnHoldForm2";
import PrimarySearchAppBar from "components/appbar/AppBarWithSideNav";
const OnHoldReport = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
      <div>
        <PrimarySearchAppBar user={user} email={email} />
        <OnholdForm2 />
      </div>
      {/* )} */}
    </>
  );
};

export default OnHoldReport;
