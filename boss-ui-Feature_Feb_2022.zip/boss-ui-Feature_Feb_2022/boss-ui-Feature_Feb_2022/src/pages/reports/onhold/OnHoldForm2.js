import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/onhold/OnholdForm.css";
import OnHoldProperties from "pages/reports/onhold/OnHoldProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/onhold/columns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";
import mockturtle from './mockturtle.json'

function OnholdForm2(props) {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [onHoldData, setonHoldData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [salesOrder, setSalesOrder] = useState("");
  const [productOrder, setProductOrder] = useState("");
  const [workOrder, setWorkOrder] = useState("");
  const [agreementId, setAgreementId] = useState("");
  const [locationNo, setLocationNo] = useState("");
  const [companyNo, setCompanyNo] = useState("");
  const [region, setRegion] = useState("");
  const [selectedVendor, setSelectedVendor] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);
  const [vendor, setVendor] = useState([]);

  
  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setonHoldData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = dateFormat(toDate, "yyyy-mm-dd HH:MM:ss");
      fromDateFormat = dateFormat(fromDate, "yyyy-mm-dd HH:MM:ss");
    }

    const data = {
      vendor: selectedVendor,
      salesOrder: salesOrder,
      productionOrder: productOrder,
      vendorWorkOrder: workOrder,
      agreementId: agreementId,
      locationNumber: locationNo,
      companyNumber: companyNo,
      fromDate: fromDateFormat,
      toDate: toDateFormat,
      region: reqRegion.toUpperCase(),
    };
    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    fetch(OnHoldProperties.onHoldService, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setonHoldData(data);
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };


  //testing only
  // const handleSearch = () => {
  //   setIsLoading(true);
  //   setonHoldData(mockturtle);
  // }
  const sendDataToParent = (name, value) => {
    if (name === "Vendor") {
      setSelectedVendor(value);
    } else if (name === "CompanyNum") {
      setCompanyNo(value);
    } else if (name === "LocationNum") {
      setLocationNo(value);
    } else if (name === "Region") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false);
    setSalesOrder("");
    setProductOrder("");
    setWorkOrder("");
    setAgreementId("");
    setLocationNo("");
    setCompanyNo("");
    setRegion("");
    setSelectedVendor("");
    checked.checkedB = false;
    setonHoldData(null);
  };
  
    useLayoutEffect(() => {
      let url;
      if (reqRegion === "dao") {
        url = OnHoldProperties.getVendorListDAO;
      } else {
        url = OnHoldProperties.getVendorListEMEA;
      }
      const arr = [];
      fetch(url)
        .then((response) => response.json())
        .then((data) => {
          data.map((item, i) => {
            arr.push(item.vendorName);
          });
  
          setVendor(arr);
        });
    }, []);
  
  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">On Hold Report</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="Sales Order"
                      onChange={(e) => setSalesOrder(e.target.value)}
                      value={salesOrder}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Production Order"
                      onChange={(e) => setProductOrder(e.target.value)}
                      value={productOrder}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Vendor Work Order"
                      onChange={(e) => setWorkOrder(e.target.value)}
                      value={workOrder}
                    />
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Region"}
                        listItems={OnHoldProperties.region}
                        sendDataToParent={sendDataToParent}
                        value={region}
                      />
                    </label>
                  </div>
                </ul>
              </div>
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"LocationNum"}
                        listItems={OnHoldProperties.locationAndCompNum}
                        sendDataToParent={sendDataToParent}
                        value={locationNo}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"CompanyNum"}
                        listItems={OnHoldProperties.locationAndCompNum}
                        sendDataToParent={sendDataToParent}
                        value={companyNo}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                        value={selectedVendor}
                      />
                    </label>
                  </div>
                  {reqRegion !== "dao" && (
                    <div className="component">
                      <TextInput
                        name="Agreement Id"
                        onChange={(e) => setAgreementId(e.target.value)}
                        value={agreementId}
                      />
                    </div>
                  )}
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  <div className="component_from_date">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                </ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onholdreport"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onholdreport"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
        <div className="result__wrapper">

          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}
         
         
           <div className="table_container">

            <div className="table_wrapper">
            

              {onHoldData && <BasicTable tdata={onHoldData} columns={COLUMNS} tablename={"emp-table"}filename={"OnHold"} rows={rows} time={time}/>}
            </div>
          </div> 
        </div>
      </div>
    </>
  );
}

export default OnholdForm2;
