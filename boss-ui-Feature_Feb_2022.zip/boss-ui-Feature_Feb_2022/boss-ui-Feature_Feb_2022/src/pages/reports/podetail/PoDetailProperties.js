const PoDetailProperties = {
  region: ["DAO", "EMEA", "APJ"],

  poDetailDAO:
    "https://podetail-service-ui-dao-ge2.pnp3.pcf.dell.com/getPODetailReport",
  poDetailEMEA:
    "https://podetail-service-ui-emea-ge2.pnp3.pcf.dell.com/getPODetailReport"
};
export default PoDetailProperties;
