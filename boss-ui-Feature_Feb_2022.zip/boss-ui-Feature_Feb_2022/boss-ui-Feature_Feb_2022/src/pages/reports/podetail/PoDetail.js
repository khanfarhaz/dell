import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/podetail/PoDetail.css";
import PoDetailProperties from "pages/reports/podetail/PoDetailProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/podetail/PoDetailColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";
import { KeyValuePairTable } from "components/tables/KeyValuePairTable";

export const PoDetail = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  // const [checked, setChecked] = React.useState({
  //   checkedB: false,
  // });

  // const handleChange = (event) => {
  //   setChecked({ ...checked, [event.target.name]: event.target.checked });
  // };

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  // const [fromDate, setFromDate] = useState(
  //   moment().format("YYYY-MM-DDThh:mm:ss")
  // );
  // const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [PoDetailData, setPoDetailData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [rows, setRows] = useState(0);
  const [region, setRegion] = useState("");
  const [salesOrder, setSalesOrder] = useState("");
  //const [region, setRegion] = useState("");
  const [productionOrder, setProductionOrder] = useState("");
  //const [salesOrder, setSalesOrder] = useState("");
  const [vendorWorkOrder, setVendorWorkOrder] = useState("");
  const [serviceTag, setServiceTag] = useState("");
  const [time, setTime] = useState(0);

  useLayoutEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const salesorderParam = queryParams.get("salesOrder");
    console.log(salesorderParam);
    console.log("testing");
    if (salesorderParam != null && salesorderParam != "") {
      const start = new Date(); //to time the service call
      setIsLoading(true);
      setPoDetailData(null);
      setSalesOrder(salesorderParam);
      const data = {
        salesOrder: salesorderParam,
        region: reqRegion.toUpperCase(),
      };

      let url;

      if (reqRegion === "dao") {
        url = PoDetailProperties.poDetailDAO;
      } else {
        url = PoDetailProperties.poDetailEMEA;
      }

      fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setRows(data.length);
          setPoDetailData(data);
          // console.log(data);
          setIsLoading(false);
          setTime(new Date() - start); //total time
        });
    }
  }, []);

  useLayoutEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const productionOrderParam = queryParams.get("productionOrder");
    console.log(productionOrderParam, "production order param");
    console.log("testing");
    if (productionOrderParam != null && productionOrderParam != "") {
      const start = new Date(); //to time the service call
      setIsLoading(true);
      setPoDetailData(null);
      setProductionOrder(productionOrderParam);
      const data = {
        productionOrder: productionOrderParam,
        region: reqRegion.toUpperCase(),
      };

      let url;

      if (reqRegion === "dao") {
        url = PoDetailProperties.poDetailDAO;
      } else {
        url = PoDetailProperties.poDetailEMEA;
      }

      fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setRows(data.length);
          setPoDetailData(data);
          // console.log(data);
          setIsLoading(false);
          setTime(new Date() - start); //total time
        });
    }
  }, []);

  useLayoutEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const vendorWorkOrderParam = queryParams.get("vendorWorkOrder");
    console.log(vendorWorkOrderParam, "vendor workorder param");
    console.log("testing");
    if (vendorWorkOrderParam != null && vendorWorkOrderParam != "") {
      const start = new Date(); //to time the service call
      setIsLoading(true);
      setPoDetailData(null);
      setVendorWorkOrder(vendorWorkOrderParam);
      const data = {
        vendorWorkOrder: vendorWorkOrderParam,
        region: reqRegion.toUpperCase(),
      };

      let url;

      if (reqRegion === "dao") {
        url = PoDetailProperties.poDetailDAO;
      } else {
        url = PoDetailProperties.poDetailEMEA;
      }

      fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setRows(data.length);
          setPoDetailData(data);
          // console.log(data);
          setIsLoading(false);
          setTime(new Date() - start); //total time
        });
    }
  }, []);

  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setPoDetailData(null);

    //let toDateFormat = "";
    //let fromDateFormat = "";

    // if (checked.checkedB === true) {
    //   toDateFormat = moment.utc(toDate);
    //   fromDateFormat = moment.utc(fromDate);
    // }

    const data = {
      productionOrder: productionOrder,
      salesOrder: salesOrder,
      vendorWorkOrder: vendorWorkOrder,
      serviceTag: serviceTag,
      region: region,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data);
    let url;

    if (reqRegion === "dao") {
      url = PoDetailProperties.poDetailDAO;
    } else {
      url = PoDetailProperties.poDetailEMEA;
    }

    console.log(JSON.stringify(data), "input to url");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setPoDetailData(data);
        console.log(data, "response data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };

  const sendDataToParent = (name, value) => {
    if (name === "Demand Region") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    setIsLoading(false);
    setRegion("");
    setServiceTag("");
    setCheckedSvcTag(false);
    setPoDetailData(null);
    setVendorWorkOrder("");
    setSalesOrder("");
    setProductionOrder("");
  };

  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">Production Order Detail Page</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="Sales Order"
                      onChange={(e) => setSalesOrder(e.target.value)}
                      value={salesOrder}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Production Order"
                      onChange={(e) => setProductionOrder(e.target.value)}
                      value={productionOrder}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Vendor Work Order Id"
                      onChange={(e) => setVendorWorkOrder(e.target.value)}
                      value={vendorWorkOrder}
                    />
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Demand Region"}
                        listItems={PoDetailProperties.region}
                        sendDataToParent={sendDataToParent}
                        value={region}
                      />
                    </label>
                  </div>
                </ul>
              </div>
              {/* <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                <div className="component">
                    <TextInput
                      name="Service Tag"
                      onChange={(e) => setServiceTag(e.target.value)}
                      value={serviceTag}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="checkbox_svctag">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkedSvcTag}
                          onChange={handleChangeSvcTag}
                          name="checkedSvcTag"
                          color="primary"
                        />
                      }
                      label="Svc Tag"
                    />
                  </div>
                 

                </ul>
              </div> */}
              <div className="formcards__wrapper_row3">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="Service Tag"
                      onChange={(e) => setServiceTag(e.target.value)}
                      value={serviceTag}
                      disabled={!checkedSvcTag}
                    />
                  </div>
                  <div className="checkbox_svctag">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkedSvcTag}
                          onChange={handleChangeSvcTag}
                          name="checkedSvcTag"
                          color="primary"
                        />
                      }
                      label="Svc Tag"
                    />
                  </div>
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items"></ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-podetail"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-podetail"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}
          {PoDetailData && <KeyValuePairTable tdata={PoDetailData} rows={rows} time={time}/>}
        </div>
      </div>
    </>
  );
};
