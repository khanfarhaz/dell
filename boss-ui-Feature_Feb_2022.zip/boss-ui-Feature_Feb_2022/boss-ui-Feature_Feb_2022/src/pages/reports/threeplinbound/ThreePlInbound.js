import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/threeplinbound/ThreePlInbound.css";
import ThreePlInboundProperties from "pages/reports/threeplinbound/ThreePlInboundProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/posummary/PoSummaryColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";

export const ThreePlInbound = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [threePlInboundData, setThreePlInboundData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [vendor, setVendor] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState("");
  const [region, setRegion] = useState("");
  const [serviceTag, setServiceTag] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);

  const [asnNumber, setAsnNumber] = useState("");
  const [vendorFacilityId, setVendorFacilityId] = useState("");



  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setThreePlInboundData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = dateFormat(toDate, "yyyy-mm-dd HH:MM:ss");
      fromDateFormat = dateFormat(fromDate, "yyyy-mm-dd HH:MM:ss");
    }

    const data = {
      threePLVendor: selectedVendor,
      asnNumber:asnNumber,  
      threePLVendorFacility:vendorFacilityId,
      fromDate: fromDateFormat,
      toDate: toDateFormat,
      serviceTag: serviceTag,
      demandRegion: region,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data,"this is data");
    let url;

    if (reqRegion === "dao") {
      url = ThreePlInboundProperties.threePlDAO;
    } else {
      url = ThreePlInboundProperties.threePlEMEA;
    }

    console.log(JSON.stringify(data),"stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setThreePlInboundData(data);
        console.log(data,"returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };

  const sendDataToParent = (name, value) => {
    if (name === "Vendor") {
      setSelectedVendor(value);
    } 
 
    else if (name === "DemandRegion") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false);
    setAsnNumber("");
    setVendorFacilityId("");

    // setSalesOrder("");
    // setProductionOrderNumber("");
    // setVendorWorkOrderNum("");
    // setAgreementId("");
    // setMergeCenterId("");
    setRegion("");
    setSelectedVendor("");
    // setSelectedLocation("");
    // setSelectedCurrentStatus("");
    // setSelectedCompanyNumber("");
    setServiceTag("");
   // setSelectedOrderType("");
    checked.checkedB = false;
    setCheckedSvcTag(false);
    setThreePlInboundData(null);
  };

  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = ThreePlInboundProperties.get3PLVendorListDAO;
    } else {
      url = ThreePlInboundProperties.get3PLVendorListEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          arr.push(item.name);
        });

        setVendor(arr);
      });
  }, []);

  

  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">3PL - Inbound ASN Receipt NACK Page</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                  <div className="component">
                    <TextInput
                      name="ASN Number"
                      onChange={(e) => setAsnNumber(e.target.value)}
                      value={asnNumber}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="3PL Vendor Facility ID	"
                      onChange={(e) => setVendorFacilityId(e.target.value)}
                      value={vendorFacilityId}
                      //disabled={checkedSvcTag}
                    />
                  </div> 
                  <div className="component">
                  <label>
                      <Dropdown
                        name={"3PL Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                        value={selectedVendor}
                      />
                    </label>
                  </div>
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                 
                
                </ul>
              </div>
              
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  
                 
         
                  
                  
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                <div className="component_from_date_asnsummary">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_asnsummary">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_asnsummary">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                  
                </ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_threepl"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_threepl"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                  {/* <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={handleReset}
                    >
                      Export to excel
                    </button>
                  </div> */}
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}
        
          {threePlInboundData && (
            <BasicTable tdata={threePlInboundData} columns={COLUMNS} tablename={"emp-table"}filename={"ThreePlInbound"} rows={rows} time={time}/>
          )}
        </div>
      </div>
    </>
  );
};
