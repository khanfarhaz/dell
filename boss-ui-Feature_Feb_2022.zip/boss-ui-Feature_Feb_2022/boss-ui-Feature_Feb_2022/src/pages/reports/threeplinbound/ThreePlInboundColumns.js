
export const COLUMNS = [
		
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "Facility",
    accessor: "facility",
  },
  {
    Header: "Reject Code;",
    accessor: "rejectCode",
  },
  {
    Header: "Reject Region",
    accessor: "rejectReason",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "ASN Number",
    accessor: "asnNumber",
  },
  {
    Header: "Demand Region",
  },
  {
    Header: "Doc Type",
    accessor: "docType",
  }
];
