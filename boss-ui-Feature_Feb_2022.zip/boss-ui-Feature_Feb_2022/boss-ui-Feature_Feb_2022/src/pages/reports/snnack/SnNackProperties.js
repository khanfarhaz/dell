const SnNackProperties =  {
  getVendorListEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
getVendorListDAO:
  "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",



  poSummaryDAO:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/getsnnack",
  poSummaryEMEA:
    "https://nackservice-ui-ge2.pnp3.pcf.dell.com/getsnnack",
 
};
export default SnNackProperties;
