import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/vendorpurchaseordernack/VendorPoNack.css";
import SnNackProperties from "pages/reports/snnack/SnNackProperties";
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/snnack/SnNackColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";

export const SnNack = () => {
  
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {

    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [snNackData, setSnNackData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [salesOrder, setSalesOrder] = useState("");
  const [productionOrder, setProductionOrderNumber] = useState("");
  const [asnNumber, setAsnNum] = useState("");
  const [serviceTag, setServiceTag] = useState("");
  const [rows, setRows] = useState(0);
  const [time, setTime] = useState(0);
  const [vendor, setVendor] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState("");
 
  const [region, setRegion] = useState("");
  
  


  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setSnNackData(null);

    let toDateFormat = "";
    let fromDateFormat = "";

    if (checked.checkedB === true) {
      toDateFormat = dateFormat(toDate, "yyyy-mm-dd HH:MM:ss");
      fromDateFormat = dateFormat(fromDate, "yyyy-mm-dd HH:MM:ss");
    }


    const data = {
      vendor: selectedVendor,
      
      asnNumber:asnNumber,
      
      fromDate: fromDateFormat,
      toDate: toDateFormat,
     
      serviceTag: serviceTag,
      demandRegion: region,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data,"this is data");
    let url;

    if (reqRegion === "dao") {
      url = SnNackProperties.poSummaryDAO;
    } else {
      url = SnNackProperties.poSummaryEMEA;
    }

    console.log(JSON.stringify(data),"stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setSnNackData(data);
        console.log(data,"returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };

  const sendDataToParent = (name, value) => {
    if (name === "Vendor") {
      setSelectedVendor(value);
      console.log("value of vendor is", selectedVendor)
    } 
    // else if (name === "Order Type") {
    //   setSelectedOrderType(value);
    // }
    // else if (name === "Location Number") {
    //   //console.log("loc no if");
    //   setSelectedLocation(value);
    // }
    // else if (name === "Current Status") {
    //   setSelectedCurrentStatus(value);
    // }
    // else if (name === "Company Number") {
    //   setSelectedCompanyNumber(value);
    // } 
    else if (name === "DemandRegion") {
      setRegion(value);
    }
  };

  const handleReset = () => {
    setFromDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setToDate(moment().format("YYYY-MM-DDThh:mm:ss"));
    setIsLoading(false);
    //setSalesOrder("");
    //setProductionOrderNumber("");
    setAsnNum("");
    //setVendorWorkOrderNum("");
    // setAgreementId("");
    // setMergeCenterId("");
    // setRegion("");
    // setSelectedVendor("");
    // setSelectedLocation("");
    // setSelectedCurrentStatus("");
    // setSelectedCompanyNumber("");
    setServiceTag("");
    //setSelectedOrderType("");
    checked.checkedB = false;
    setCheckedSvcTag(false);
    setSnNackData(null);
  };

  useLayoutEffect(() => {
    let url;
    if (reqRegion === "dao") {
      url = SnNackProperties.getVendorListDAO;
    } else {
      url = SnNackProperties.getVendorListEMEA;
    }
    const arr = [];
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map((item, i) => {
          arr.push(item.vendorName);
        });

        setVendor(arr);
      });
  }, []);

  // useLayoutEffect(() => {
  //   let url;
  //   if (reqRegion === "dao") {
  //     url = SnNackProperties.getLocationNumberDAO;
  //   } else {
  //     url = SnNackProperties.getLocationNumberEMEA;
  //   }
  //   const arr = [];
  //   fetch(url)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       data.map((item, i) => {
  //         arr.push(item.locNumber);
  //       });

  //       setLocationNumber(arr);
  //     });
  // }, []);

  // useLayoutEffect(() => {
  //   let url;
  //   if (reqRegion === "dao") {
  //     url = SnNackProperties.getCompanyNumberDAO;
  //   } else {
  //     url = SnNackProperties.getCompanyNumberEMEA;
  //   }
  //   const arr = [];
  //   fetch(url)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       data.map((item, i) => {
  //         arr.push(item.companyNumber);
  //       });

  //       setCompanyNumber(arr);
  //     });
  // }, []);

  // useLayoutEffect(() => {
  //   let url;
  //   if (reqRegion === "dao") {
  //     url = SnNackProperties.getCurrentStatusDAO;
  //   } else {
  //     url = SnNackProperties.getCurrentStatusEMEA;
  //   }
  //   const arr = [];
  //   fetch(url)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       data.map((item, i) => {
  //         arr.push(item.statusCode);
  //       });

  //       setCurrentStatus(arr);
  //     });
  // }, []);

 

  // useLayoutEffect(() => {
  //   let url;
  //   if (reqRegion === "dao") {
  //     url = VendorPoNackProperties.getOrderTypeDAO;
  //   } else {
  //     url = VendorPoNackProperties.getOrderTypeEMEA;
  //   }
  //   const arr = [];
  //   fetch(url)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       data.map((item, i) => {
  //         if (item != null) {
  //           arr.push(item.orderType);
  //         }
  //       });

  //       setOrderType(arr);
  //       //console.log(arr);
  //     });
  // }, []);

  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">SN NACK</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                <div className="dropdown_component">
                <label>
                      <Dropdown
                        name={"Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                        value={selectedVendor}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <TextInput
                      name="ASN No"
                      onChange={(e) => setAsnNum(e.target.value)}
                      value={asnNumber}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  {/* <div className="component">
                    <TextInput
                      name="Sales Order Number"
                      onChange={(e) => setSalesOrder(e.target.value)}
                      value={salesOrder}
                      disabled={checkedSvcTag}
                    />
                  </div> */}
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Demand Region"}
                        listItems={SnNackProperties.region}
                        sendDataToParent={sendDataToParent}
                        value={region}
                      />
                    </label>
                  </div>
                  {/* <div className="component">
                    <TextInput
                      name="Production Order"
                      onChange={(e) => setProductionOrderNumber(e.target.value)}
                      value={productionOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Vendor Work Order"
                      onChange={(e) => setVendorWorkOrderNum(e.target.value)}
                      value={vendorWorkOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Family/Base type"
                      onChange={(e) => setBaseType(e.target.value)}
                      value={baseType}
                      //disabled={checkedSvcTag}
                    />
                  </div> */}
                   {/* <div className="component">
                    <label>
                      <Dropdown
                        name={"3PL Vendor Facility ID"}
                        listItems={VendorPoNackProperties.ordertype}
                        sendDataToParent={sendDataToParent}
                        value={orderType}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"3PL Vendor"}
                        listItems={VendorPoNackProperties.ordertype}
                        sendDataToParent={sendDataToParent}
                        value={orderType}
                      />
                    </label>
                  </div> */}
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                {/* <div className="line2_component">
                    <label>
                      <Dropdown
                        name={"Demand Region"}
                        listItems={VendorPoNackProperties.region}
                        sendDataToParent={sendDataToParent}
                        value={region}
                      />
                    </label>
                  </div> */}
                 
                  {/* <div className="component">
                    <label>
                      <Dropdown
                        name={"Demand Region"}
                        listItems={VendorPoNackProperties.region}
                        sendDataToParent={sendDataToParent}
                        value={region}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Company Number"}
                        listItems={companyNo}
                        sendDataToParent={sendDataToParent}
                        value={selectedCompanyNumber}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Location number"}
                        listItems={locationNo}
                        sendDataToParent={sendDataToParent}
                        value={selectedLocation}
                       // disabled={checkedSvcTag}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Vendor"}
                        listItems={vendor}
                        sendDataToParent={sendDataToParent}
                        value={selectedVendor}
                      />
                    </label>
                  </div>
                  <div className="component">
                    <label>
                      <Dropdown
                        name={"Current Status"}
                        listItems={currentStatus}
                        sendDataToParent={sendDataToParent}
                        value={selectedCurrentStatus}
                      />
                    </label>
                  </div> */}
                 
                </ul>
              </div>
              
              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                  
                  
                  {/* <div className="component">
                    <TextInput
                      name="MCID"
                      onChange={(e) => setMergeCenterId(e.target.value)}
                      value={mergeCenterId}
                      //disabled={checkedSvcTag}
                    />
                  </div>
                  {reqRegion !== "dao" && (
                    <div className="component">
                      <TextInput
                        name="Agreement Id"
                        onChange={(e) => setAgreementId(e.target.value)}
                        value={agreementId}
                        disabled={checkedSvcTag}
                      />
                    </div>
                  )}
                  <div className="component">
                    <TextInput
                      name="Service Tag"
                      onChange={(e) => setServiceTag(e.target.value)}
                      value={serviceTag}
                      disabled={!checkedSvcTag}
                    />
                  </div>
                  <div className="checkbox_svctag">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkedSvcTag}
                          onChange={handleChangeSvcTag}
                          name="checkedSvcTag"
                          color="primary"
                        />
                      }
                      label="Svc Tag"
                    />
                  </div> */}
                   
                
                  
                  
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">
                <div className="component_from_date_asnsummary">
                    <label>
                      <DateTimePicker
                        name="From"
                        onChange={(newValue) => {
                          setFromDate(newValue.target.value);
                        }}
                        disabled={!checked.checkedB}
                        value={fromDate}
                      />
                    </label>
                  </div>
                  <span>
                    <div className="component_date_asnsummary">
                      <label>
                        <DateTimePicker
                          name="To"
                          onChange={(newValue) => {
                            setToDate(newValue.target.value);
                          }}
                          disabled={!checked.checkedB}
                          value={toDate}
                        />
                      </label>
                    </div>
                  </span>

                  <div className="component_checkbox_asnsummary">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked.checkedB}
                          onChange={handleChange}
                          name="checkedB"
                          color="primary"
                        />
                      }
                      label="Dates"
                    />
                  </div>
                </ul>
                <ul className="formcards__items">
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_oppfailed"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold_oppfailed"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>
                  {/* <div className="component_search">
                    <button
                      type="button"
                      className="btnnew-onhold"
                      onClick={handleReset}
                    >
                      Export to excel
                    </button>
                  </div> */}
                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}      
    
          {snNackData && (
            <BasicTable tdata={snNackData} columns={COLUMNS} tablename={"emp-table"}filename={"SnNack"} rows={rows} time={time}/>
          )}
        </div>
      </div>
    </>
  );
};

