const AsnProperties = {

  getVendorListEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
getVendorListDAO:
  "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",
  snSummaryDAO:
    "https://shipnoticereports-ui-dao-ge2.pnp3.pcf.dell.com/getShipNoticeSummary",
  snSummaryEMEA:
    "https://shipnoticereports-ui-emea-ge2.pnp3.pcf.dell.com/getShipNoticeSummary",
  
};
export default AsnProperties;
