import { React, useState, useLayoutEffect } from "react";
import { SnHold } from "pages/reports/snholdlog/SnHold";
import PrimarySearchAppBar from "components/appbar/AppBarWithSideNav";

export const SnHoldReport = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState(null);
  useLayoutEffect(() => {
    if (localStorage.getItem("bossui-user") !== null) {
      setUser(localStorage.getItem("bossui-user"));
      setEmail(localStorage.getItem("email"));
    }
  }, []);
  return (
    <>
      {/* {user && ( */}
      <div>
        <PrimarySearchAppBar user={user} email={email} />
        <SnHold />
      </div>
      {/* )} */}
    </>
  );
};
