const PoSummaryProperties =  {
  region: ["DAO", "EMEA", "APJ"],
  ordertype:["BTS","CTO","PLB","PLP","PLS","PLT","RTL","FGA","ALL"],

  getVendorListEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getvendors",
getVendorListDAO:
  "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getvendors",

  getOrderTypeEMEA:
    "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getordertypes",
  getOrderTypeDAO:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getordertypes",

  getLocationNumberEMEA:
  "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getlocationnumbers",
  getLocationNumberDAO:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getlocationnumbers",

  getCompanyNumberEMEA:
    "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getcompanynumbers",
  getCompanyNumberDAO:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getcompanynumbers",

  getCurrentStatusEMEA:
    "https://reporthelper-ui-emea-ge4.pnp3.pcf.dell.com/getorderstatuses",
  getCurrentStatusDAO:
    "https://reporthelper-ui-dao-ge4.pnp3.pcf.dell.com/getorderstatuses",


  poSummaryDAO:
    "https://po-service-ui-dao-ge2.pnp3.pcf.dell.com/getproductionorders",
  poSummaryEMEA:
    "https://po-service-ui-emea-ge2.pnp3.pcf.dell.com/getproductionorders",
 
};
export default PoSummaryProperties;
