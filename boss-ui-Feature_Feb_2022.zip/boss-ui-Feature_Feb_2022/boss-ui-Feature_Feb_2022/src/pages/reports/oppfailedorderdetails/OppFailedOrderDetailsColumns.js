

export const COLUMNS = [
  								
  {
    Header: "Vendor",
    accessor: "vendor",
  },
  {
    Header: "Reject Code",
    accessor: "rejectCode",
  },
  {
    Header: "Reject Reason",
    accessor: "rejectReason",
  },
  {
    Header: "Reject Detail",
    accessor: "rejectDetail",
  },
  {
    Header: "Received Time",
    accessor: "receivedTime",
  },
  {
    Header: "GPO",
    accessor: "gpo",
  },
  {
    Header: "VPO",
    accessor: "vpo",
  },
  {
    Header: "Sales Order No",
    accessor: "salesOrderNo",
  },
  		
  {
    Header: "Tie Num",
    accessor: "tieNum",
  },
  {
    Header: "Family",
    accessor: "family",
  },
  {
    Header: "	OS Token Type",
    accessor: "osTokenType",
  },
  {
    Header: "OS Lang	Parts",
    accessor: "osLangParts",
  }
];
