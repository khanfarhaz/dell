import React, { useState, useEffect, useLayoutEffect, useRef } from "react";
import "pages/reports/vendorworkorder/VendorWorkOrder.css";
import VwoStatusHistoryProperties from "pages/reports/vwostatushistory/VwoStatusHistoryProperties";
import VendorWorkOrderProperties from "pages/reports/vendorworkorder/VendorWorkOrderProperties"
import Dropdown from "components/dropdown/Dropdown";
import { useRouteMatch } from "react-router-dom";
import { BasicTable } from "components/tables/BasicTable";
import { LoadingCircle } from "components/loader/LoadingCircle";
import TextInput from "components/textinput/TextInput";
import DateTimePicker from "components/dateandtime/DateTimePicker";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import ColoredLine from "components/coloredline/ColoredLine";
import { COLUMNS } from "pages/reports/vendorworkorder/VendorWorkOrderColumns";
import dateFormat from "dateformat";
import moment, { isMoment } from "moment";

export const VendorWorkOrder = () => {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const [checked, setChecked] = React.useState({
    checkedB: false,
  });

  const [checkedSvcTag, setCheckedSvcTag] = useState(false);

  const handleChange = (event) => {
    setChecked({ ...checked, [event.target.name]: event.target.checked });
  };

  const handleChangeSvcTag = () => {
    // alert(checkedSvcTag);
    // if(checkedSvcTag===false){}
    setCheckedSvcTag(!checkedSvcTag);
  };

  const [fromDate, setFromDate] = useState(
    moment().format("YYYY-MM-DDThh:mm:ss")
  );
  //const [toDate, setToDate] = useState(moment().format("YYYY-MM-DDThh:mm:ss"));
  const [vendorWorkorderData, setVendorWorkorderData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [rows, setRows] = useState(0);
  const [salesOrder, setSalesOrder] = useState("");
  const [productionOrder, setProductionOrderNumber] = useState("");
  const [workorderid, setVendorWorkOrderNum] = useState("");
  const [serviceTag, setServiceTag] = useState("");

  const [time, setTime] = useState(0);

  const handleSearch = () => {
    const start = new Date();
    setIsLoading(true);
    setVendorWorkorderData(null);

    const data = {
      rowCount: 10,
      productionOrder: productionOrder,
      salesOrder: salesOrder,
      workOrderId: workorderid,
      serviceTag: serviceTag,
      region: reqRegion.toUpperCase(),
    };

    for (var propName in data) {
      if (data[propName] === null || data[propName] === "") {
        delete data[propName];
      }
    }
    console.log(data, "this is data");
    let url;

    if (reqRegion === "dao") {
      url = VendorWorkOrderProperties.vendorWODAO;
    } else {
      url = VendorWorkOrderProperties.vendorWOEMEA;
    }

    console.log(JSON.stringify(data), "stringified data");
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setRows(data.length);
        setVendorWorkorderData(data);
        console.log(data, "returned data");
        setIsLoading(false);
        setTime(new Date() - start);
      });
  };


  const handleReset = () => {
    setIsLoading(false);
    setSalesOrder("");
    setProductionOrderNumber("");
    setVendorWorkOrderNum("");
    setServiceTag("");
    checked.checkedB = false;
    setCheckedSvcTag(false);
    setVendorWorkorderData(null);
  };



  return (
    <>
      <div>
        <div className="uIformcards">
          <div className="uIformcards__container">
            <div className="narrative">Vendor Work Order Report</div>
            <form id="on-hold-form">
              <div className="formcards__wrapper">
                <ul className="formcards__items">
                </ul>
              </div>

              <div className="formcards__wrapper_row">
                <ul className="formcards__items">


                  <div className="component">
                    <TextInput
                      name="Sales Order"
                      onChange={(e) => setSalesOrder(e.target.value)}
                      value={salesOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Production Order"
                      onChange={(e) => setProductionOrderNumber(e.target.value)}
                      value={productionOrder}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Vendor Work Order"
                      onChange={(e) => setVendorWorkOrderNum(e.target.value)}
                      value={workorderid}
                      disabled={checkedSvcTag}
                    />
                  </div>
                  <div className="component">
                    <TextInput
                      name="Service Tag"
                      onChange={(e) => setServiceTag(e.target.value)}
                      value={serviceTag}
                      disabled={!checkedSvcTag}
                    />
                  </div>

                  <div className="checkbox_svctag">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkedSvcTag}
                          onChange={handleChangeSvcTag}
                          name="checkedSvcTag"
                          color="primary"
                        />
                      }
                      label="Svc Tag"
                    />

                  </div>

                </ul>
              </div>

              <div className="formcards__wrapper_row3">
                <ul className="formcards__items">



                </ul>
              </div>

              <div className="formcards__wrapper_row3">
                <ul className="formcards__items">




                </ul>
                <ul className="formcards__items">
                  <div className="component_search_venwo">
                    <button
                      type="button"
                      className="btnnew-vendorwo"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>
                  <div className="component_search_venwo">
                    <button
                      type="button"
                      className="btnnew-vendorwo"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                  </div>

                </ul>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="result__container">
      <div className="result__wrapper">
          <ColoredLine color="blue" />
          {isLoading && <LoadingCircle />}

          {vendorWorkorderData && (
            <BasicTable tdata={vendorWorkorderData} columns={COLUMNS} tablename={"emp-table"} filename={"VendorWorkOrder"} rows={rows} time={time}/>
          )}
        </div>
      </div>
    </>
  );
};






