
export const COLUMNS = [
  // {
  //   Header: "Sales Order",
  //   accessor: "salesOrder",
  //   Cell: (e) => (
  //     <a
  //       href={`po-detail?salesOrder=${e.value}`}
  //       target="_blank"
  //       rel="noopener noreferrer"
  //     >
  //       {e.value}
  //     </a>
  //   ),
  // },
  						
  {
    Header: "Line Item Num",
    accessor: "lineItemNum",
  },
  {
    Header: "Base Part Num",
    accessor: "basePartNum",
  },
  {
    Header: "Base Part Desc",
    accessor: "basePartDesc",
  },
  {
    Header: "Tie Group",
    accessor: "tieGroup",
  },
  {
    Header: "Tie Group Qty",
    accessor: "tieGroupQty",
  },
  {
    Header: "Price Currency",
    accessor: "priceCurrency",
    // Cell: (e) => (
    //   <a
    //     href={`po-detail?productionOrder=${e.value}`}
    //     target="_blank"
    //     rel="noopener noreferrer"
    //   >
    //     {e.value}
    //   </a>
    // ),
  },
  					
  {
    Header: "Unit Price",
    accessor: "uprice",
  },
  {
    Header: "Demand Region",
    accessor: "region",
    // Cell: (e) => (
    //   <a
    //     href={`po-detail?vendorWorkOrder=${e.value}`}
    //     target="_blank"
    //     rel="noopener noreferrer"
    //   >
    //     {e.value}
    //   </a>
    // ),
    
  },
  
  {
    Header: "SSC Type",
    accessor: "ssc",
  },
  {
    Header: "Created By",
    accessor: "createdBy",
  },
  {
    Header: "Creation Date",
    accessor: "createdDate",
  },
  {
    Header: "Service_Tag",
    accessor: "serviceTag",
  },
  // {
  //   Header: "Order Type",
  //   accessor: "orderType",
  // },
  // {
  //   Header: "SSC Type",
  //   accessor: "sscType",
  // },
  // {
  //   Header: "Quantity",
  //   accessor: "quantity",
  // },
  // {
  //   Header: "MCID",
  //   accessor: "mcid",
  // },
  // {
  //   Header: "OPP NACK",
  //   accessor: "oppNack",
  // },
  // {
  //   Header: "Status Time Stamp",
  //   accessor: "statusTimestamp",
  // },
  // {
  //   Header: "Previous Status",
  //   accessor: "previousStatus",
  // },
  // {
  //   Header: "Current Status",
  //   accessor: "currentStatus",
  // },
  // {
  //   Header: "CO Num",
  //   accessor: "coNum",
  // },

  // {
  //   Header: "LOC Num",
  //   accessor: "locNum",
  // },
  // {
  //   Header: "Service Tag",
  //   accessor: "serviceTag",
  // }
];
