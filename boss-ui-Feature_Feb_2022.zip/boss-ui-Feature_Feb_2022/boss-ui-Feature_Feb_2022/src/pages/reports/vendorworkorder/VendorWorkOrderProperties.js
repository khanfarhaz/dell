const VendorWorkOrderProperties =  {

  vendorWODAO:
    "https://vendorworkorderdetail-ui-dao-ge2.pnp3.pcf.dell.com/getvendorworkorderdetails",
  vendorWOEMEA:
    "https://vendorworkorderdetail-ui-emea-ge2.pnp3.pcf.dell.com/getvendorworkorderdetails",
 
};
export default VendorWorkOrderProperties;
