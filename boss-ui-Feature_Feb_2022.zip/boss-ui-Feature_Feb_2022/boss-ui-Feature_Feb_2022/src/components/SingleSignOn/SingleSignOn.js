import { useState, useEffect } from "react";

const SingleSignOn = () => {
  const getUserName = () => {
    console.log(localStorage.getItem("bossui-user"));
    if (localStorage.getItem("bossui-user") === null) {
      window.location = "https://single-sign-on.ausvtc01.pcf.dell.com/";
    }
  };

  return <>{getUserName()}</>;
};

export default SingleSignOn;
