import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "components/navbar/Navbar.css";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import { SidebarData } from "./SidebarData";
import { IconContext } from "react-icons";
import * as IOIcons from "react-icons/io";

function NavbarwithSidebar() {
  const [click, setClick] = useState(false);
  const [button, setButton] = useState(true);
  const [sidebar, setSidebar] = useState(true);
  const [dropdown, setDropdown] = useState(false);

  const handleClick = () => setClick(!click);
  const closeMobileMenu = () => setClick(false);

  const showSidebar = () => setSidebar(!sidebar);

  const onMouseEnter = () => {
    if (window.innerWidth < 960) {
      setDropdown(false);
    } else {
      setDropdown(true);
    }
  };

  const onMouseLeave = () => {
    if (window.innerWidth < 960) {
      setDropdown(false);
    } else {
      setDropdown(false);
    }
  };

  const showButton = () => {
    if (window.innerWidth <= 960) {
      setButton(false);
    } else {
      setButton(true);
    }
  };

  useEffect(() => {
    showButton();
  }, []);

  window.addEventListener("resize", showButton);

  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          <IconContext.Provider value={{ color: "#fff" }}>
            <div className="sidenavbar">
              <Link to="#" className="sidemenu-bars">
                <FaIcons.FaBars onClick={showSidebar} />
              </Link>
            </div>
            <nav className={sidebar ? "sidenav-menu active" : "sidenav-menu"}>
              <ul className="sidenav-menu-items" onClick={showSidebar}>
                <li className="sidenavbar-toggle">
                  <Link to="#" className="sidemenu-bars">
                    <AiIcons.AiOutlineClose />
                  </Link>
                </li>
                {SidebarData.map((item, index) => {
                  return (
                    <li key={index} className={item.cName}>
                      <Link to={item.path}>
                        {item.icon}
                        <span>{item.title}</span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </nav>
          </IconContext.Provider>
          <Link
            to="/"
            className={sidebar ? "navbar-logoclicked" : "navbar-logo"}
            onClick={closeMobileMenu}
          >
            <div
              className={
                sidebar ? "imageslider-clicked" : "imageslider-unclicked"
              }
            ></div>
            <img
              className="logo-img-navbarwithsidebar"
              src="images/dell_technologies_logo.png"
            />
          </Link>
          {/* <Link>
          <div className={'imageslider-unclicked'}></div>
            <img className='logo-img'src='images/Dell_technologieslogo.jfif'/>
          </Link> */}
          {/* <div className='nav-item'>
          <h1 className='boss'>BOSS UI</h1>
          </div> */}
          <div className="menu-icon" onClick={handleClick}>
            <i className={click ? "fas fa-times" : "fas fa-bars"} />
          </div>
          <ul className={click ? "nav-menu active" : "nav-menu"}>
            <li className="nav-item">
              <Link to="/" className="nav-links" onClick={closeMobileMenu}>
                <div className="IoIosHelp">
                  <IOIcons.IoIosBook />
                </div>
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/" className="nav-links" onClick={closeMobileMenu}>
                <div className="IoMdSettings">
                  <IOIcons.IoMdSettings />
                </div>
              </Link>
            </li>

            <li
              className="nav-item"
              onMouseEnter={onMouseEnter}
              onMouseLeave={!onMouseLeave}
            >
              <Link to="/services"></Link>
              {/* { <Dropdown />} */}
            </li>

            <li className="nav-item">
              <Link className="nav-userlinks" onClick={closeMobileMenu}>
                <div className="IoMdContact">
                  <li>
                    <IOIcons.IoMdContact />{" "}
                  </li>
                </div>
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </>
  );
}

export default NavbarwithSidebar;
