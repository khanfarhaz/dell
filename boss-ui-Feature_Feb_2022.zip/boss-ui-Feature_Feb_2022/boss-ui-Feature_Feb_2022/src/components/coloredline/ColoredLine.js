import React from "react";

export default function ColoredLine(props) {
  return (
    <div>
      <hr
        style={{
          color: props.color,
          backgroundColor: props.color,
          height: 3,
          width: "75%",
          align: "center",
          margin: "auto",
        }}
      />
    </div>
  );
}
