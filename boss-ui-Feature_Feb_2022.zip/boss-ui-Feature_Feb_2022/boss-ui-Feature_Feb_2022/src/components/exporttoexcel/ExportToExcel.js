import React, { useMemo } from "react";
import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";
import { Button } from "components/button/Button";
export const ExportToExcel = (props) => {

    var data1 = useMemo(() => props.data1);
    var data2 = useMemo(() => props.data2);
    var data3 = useMemo(() => props.data3);
    var concatdata=[];
    concatdata.push(data1);
    concatdata.push(data2);
    concatdata.push(data3);
    //console.log(concatdata,"concatinated data"); 
    
    const fileName= useMemo(() => props.filename, []);

    const sheet1= useMemo(() => props.sheet1, []);
    const sheet2= useMemo(() => props.sheet2, []);
    const sheet3= useMemo(() => props.sheet3, []);

    const fileType =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
    const fileExtension = ".xlsx";


  const exportToCSV = (apiData, fileName) => {
    const wb = {SheetNames:[], Sheets: {} };
    if(apiData!=null)
    {
        if(apiData[0]!=null)
        {
    var ws1 = XLSX.utils.json_to_sheet(apiData[0]);
    wb.SheetNames.push(sheet1); wb.Sheets[sheet1]=ws1
        }
        else{
            var ws1=null;
        }
        if(apiData[1]!=null)
        {
    var ws2 = XLSX.utils.json_to_sheet(apiData[1]);
    wb.SheetNames.push(sheet2); wb.Sheets[sheet2]=ws2
        }
        else{
            var ws2=null;

        }
        if(apiData[2]!=null)
        {
    var ws3 = XLSX.utils.json_to_sheet(apiData[2]);
     
    wb.SheetNames.push(sheet3); wb.Sheets[sheet3]=ws3
        }
        else{
            var ws3=null;
        }
    }

   
   

    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: fileType });
    FileSaver.saveAs(data, fileName + fileExtension);
  };

  return (    
    <div className="component_search_asndetail">
    <button
      type="button"
      className="btnnew-onhold"
      onClick={(e) =>exportToCSV(concatdata, fileName)}
    >
      Export all
    </button>
  </div>
  );
};

