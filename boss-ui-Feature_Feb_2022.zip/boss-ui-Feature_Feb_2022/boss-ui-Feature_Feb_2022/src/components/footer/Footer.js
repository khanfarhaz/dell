import React, { useState, useEffect } from "react";
import "components/footer/Footer.css";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <div className="footer-container">
      <section class="social-media">
        <div class="social-media-wrap">
          <div>
            <Link>BOSS</Link>
          </div>
          <div>
            <Link>GOLF</Link>
          </div>
          <div>
            <Link>OFS</Link>
          </div>
          <div class="footer-logo"></div>
          <small class="website-rights">DELL © 2020</small>
        </div>
      </section>
    </div>
  );
}

export default Footer;
