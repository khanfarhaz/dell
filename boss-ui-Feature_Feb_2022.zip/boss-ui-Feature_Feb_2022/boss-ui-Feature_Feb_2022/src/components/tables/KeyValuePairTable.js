import React, { useMemo, useState } from "react";
import "./tableskeyvalue.css";
import {
  useTable,
  useSortBy,
  usePagination,
  useGlobalFilter,
} from "react-table";
//import { COLUMNS } from "../columns";
import { FaCaretSquareUp, FaCaretSquareDown } from "react-icons/fa";
//import "components/tables/table.css";
import { makeStyles,withStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { Button } from "components/button/Button";
import ReactHTMLTableToExcel from "react-html-table-to-excel";
import InputBase from "@material-ui/core/InputBase";
import exportFromJSON from 'export-from-json' ;
import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";
import { ExportToExcel } from "components/exporttoexcel/ExportToExcel";

export const KeyValuePairTable = (props) => {

 
  const [page, setPage] = useState(1);
  const [shippingPage, setShippingPage] = useState(0);
  const [billingPage, setBillingPage] = useState(0);
  const PoDetailData = useMemo(() => props.tdata, []);
  const tableRows=useMemo(() => props.rows, []);
  const time=useMemo(() => props.time, []);
  
  const nextPage = () => {
    setPage(page + 1);
  };
  const canNextPage = () => {
    if (page > PoDetailData.length - 1) {
      return false;
    }
    return true;
  };
  const previousPage = () => {
    setPage(page - 1);
  };

  const canPreviousPage = () => {
    if (page < 2) {
      return false;
    }
    return true;
  };

  const orderDetails = PoDetailData.map((x) => x.orderDetails).flat(1);

  const billingDetails = PoDetailData.map((x) => x.billingDetails).flat(1);

  const shippingDetails = PoDetailData.map((x) => x.shippingDetails).flat(1);

  const newOrderDetailsArray = orderDetails.map((item) => {
    return {
      "Production Order": item.productionOrder,
      "Sales Order": item.salesOrder,
      "Vendor Work Order": item.vendorWorkOrderId,
      "Order Classification": item.orderClassification,
      "Order Type": item.orderType,
      "Demand Region": item.region,
      "SSC Type": item.sscType,
      "Blanket PO": item.blanketPoNum,
      "Actual PO": item.actualPoNum,
      "Order Date": item.orderDate,
      "Create Date": item.createDate,
      "Ship By Date": item.shipByDate,
      "Pend Production Date": item.pendProductionDate,
      "In Production Date": item.inProductionDate,
      "Total Price": item.totalPrice,
      Currency: item.currency,
      "Order Quantity": item.orderQty,
      International: item.international,
      "Family Code": item.familyCode,
      "Work Center": item.workCenter,
      "Base Type Code": item.baseTypeCode,
      "Base Part Num": item.basePartNum,
      "Base Part Desc": item.basePartDesc,
      "Order Priority": item.orderPriority,
      "Service Tag": item.serviceTag,
      "CO NUM": item.companyNum,
      "LOC NUM": item.locationNum,
      "Must Arrive By Date": item.mabd,
    };
  });

  const newBillingDetailsArray = billingDetails.map((item) => {
    return {
      "Billing name": item.billingName,
      "Billing Company Name": item.billingComapny,
      "Billing Address 1": item.billingAddress1,
      "Billing Address 2": item.billingAddress2,
      "Billing city": item.billingCity,
      "Billing State": item.billingState,
      "Billing Code": item.billingCode,
    };
  });
 

  const newShippingDetailsArray = shippingDetails.map((item) => {
    return {
      "Ship Method": item.shipMethod,
      "Partial Ship": item.partialShip,
      "Carrier": item.carrierCode,
      "Shipping Name": item.shippingName,
      "Shipping Company Name": item.shippingCompanyName,
      "Shipping Address 1": item.shippingAddress1,
      "Shipping Address 2": item.shippingAddress2,
      "Shipping City": item.shippingCity,
      "Shipping State": item.shippingState,
      "Shipping Country": item.shippingCountry,
    };
  });

  const BootstrapInput = withStyles((theme) => ({
    root: {
      "label + &": {
        marginTop: theme.spacing(2)
      }
    },
    input: {
      borderRadius: 4,
      position: "relative",
      backgroundColor: theme.palette.background.paper,
      //marginLeft:400,
      border: "1px solid #ced4da",
      fontSize: 16,
      padding: "1px 20px 1px 1px",
      transition: theme.transitions.create(["border-color", "box-shadow"]),
      // Use the system font instead of the default Roboto font.
      fontFamily: [
        "-apple-system",
        "BlinkMacSystemFont",
        '"Segoe UI"',
        "Roboto",
        '"Helvetica Neue"',
        "Arial",
        "sans-serif",
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"'
      ].join(","),
      "&:focus": {
        borderRadius: 4,
        borderColor: "#80bdff",
        boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
        //marginLeft:400,
      }
    }
  }))(InputBase);
  
  const useStyles = makeStyles((theme) => ({
    margin: {
      margin: theme.spacing(1),
      marginLeft:480,
      marginTop:-65
    }
  }));
  
  const exporttable=useMemo(() => props.tablename, []);
  const classes = useStyles();
 


  return (
    <>
   
   <label className="rowsT" htmlFor="text">
             <p> Rows :{tableRows}  &emsp;   Time:{time} ms</p>
            </label>

      <div className="exporttoexcelPoDetail">
     <ExportToExcel  data1={newBillingDetailsArray} data2={newOrderDetailsArray} data3={newShippingDetailsArray}
                   filename="PO Detail report" sheet1="Billing details" sheet3="Order details" sheet2="Shipping details"/>
     </div>
      <div className="table1" >
     
        <table className="table table-hover" id="exporttable">
          <tbody>
            <th colSpan="2">
              <tr>Order Details</tr>
              <tr></tr>
            </th>

            {Object.keys(newOrderDetailsArray[page - 1]).map((key, i) => (
              <tr className="table-row">
                <td>{key}</td>
                <td>{newOrderDetailsArray[page - 1][key]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="table2">
        <table className="table table-hover" id="exporttable">
          <tbody>
            <th colSpan="2">
              <tr>Billing Details</tr>
              <tr></tr>
            </th>

            {Object.keys(newBillingDetailsArray[page - 1]).map((key, i) => (
              <tr className="table-row">
                <td>{key}</td>
                <td>{newBillingDetailsArray[page - 1][key]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="table3">
        <table className="table table-hover">
          <tbody>
            <th colSpan="2">
              <tr>Shipment Details</tr>
              <tr></tr>
            </th>

            {Object.keys(newShippingDetailsArray[page - 1]).map((key, i) => (
              <tr className="table-row">
                <td>{key}</td>
                <td>{newShippingDetailsArray[page - 1][key]}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="buttons_container">
          <div className="buttons_wrapper">
            <div>
              <span>
                <Button
                  type="button"
                  className="page1"
                  onClick={() => setPage(1)}
                  disabled={!canPreviousPage}
                >
                  {"<<"}
                </Button>
                <Button
                  type="button"
                  className="prevbtn"
                  disabled={!canPreviousPage()}
                  onClick={() => previousPage()}
                >
                  Prev{page}
                </Button>
                <Button
                  type="button"
                  className="nextbtn"
                  disabled={!canNextPage()}
                  onClick={() => nextPage()}
                >
                  Next{page}
                </Button>
                <Button
                  type="button"
                  className="lastpage"
                  onClick={() => setPage(PoDetailData.length)}
                  disabled={!canNextPage}
                >
                  {">>"}
                </Button>
              </span>
            </div>
            <div className='exporttoexcel'>
         

 </div >
 <div classname="exporttoexcelPoDetail"/>

          </div>
        </div>
      </div>
    </>
  );
};
