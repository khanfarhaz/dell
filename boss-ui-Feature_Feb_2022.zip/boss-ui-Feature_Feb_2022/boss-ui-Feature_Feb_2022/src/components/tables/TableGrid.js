import React from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  root: {
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
  },
}))(TableRow);

const useStyles = makeStyles({
  table: {
    minWidth: 700,
  },
});

export default function TableGrid(props) {
  const resp = props.resp;
  const classes = useStyles();

  return (
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>Vendor</StyledTableCell>
            <StyledTableCell align="right">Delay_Reason</StyledTableCell>
            <StyledTableCell align="right">Reason_Desc</StyledTableCell>
            <StyledTableCell align="right">Received_Time</StyledTableCell>
            <StyledTableCell align="right">Production_Order</StyledTableCell>
            <StyledTableCell align="right">Vendor_Work_Order</StyledTableCell>
            <StyledTableCell align="right">Demand_Region</StyledTableCell>
            <StyledTableCell align="right">SSC_Type</StyledTableCell>
            <StyledTableCell align="right">Sales Order No</StyledTableCell>
            <StyledTableCell align="right">Company No</StyledTableCell>
            <StyledTableCell align="right">Location No</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {resp.map((list, index) => (
            <StyledTableRow key={index}>
              <StyledTableCell component="th" scope="row">
                {list.vendor}
              </StyledTableCell>
              <StyledTableCell align="right">{list.rejectCode}</StyledTableCell>
              <StyledTableCell align="right">
                {list.rejectReason}
              </StyledTableCell>
              <StyledTableCell align="right">
                {list.receivedTime}
              </StyledTableCell>
              <StyledTableCell align="right">{list.gpo}</StyledTableCell>
              <StyledTableCell align="right">{list.vpo}</StyledTableCell>
              <StyledTableCell align="right">
                {list.demandRegion}
              </StyledTableCell>
              <StyledTableCell align="right">{list.sscType}</StyledTableCell>
              <StyledTableCell align="right">
                {list.salesOrderNo}
              </StyledTableCell>
              <StyledTableCell align="right">{list.companyNum}</StyledTableCell>
              <StyledTableCell align="right">
                {list.locationNum}
              </StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
