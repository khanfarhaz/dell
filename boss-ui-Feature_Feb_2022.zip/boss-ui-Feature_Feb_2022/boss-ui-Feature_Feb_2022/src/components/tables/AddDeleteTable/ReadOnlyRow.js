import React from "react";
// import Dialog from "@material-ui/core/Dialog";
// import DialogActions from "@material-ui/core/DialogActions";
// import DialogContent from "@material-ui/core/DialogContent";
// import DialogContentText from "@material-ui/core/DialogContentText";
// import DialogTitle from "@material-ui/core/DialogTitle";
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

const ReadOnlyRow = ({ contact, handleEditClick, handleDeleteClick, showConfirm,
  handleNo }) => {

	const [open, setOpen] = React.useState(false);

	const handleClickOpen = () => {
	  setOpen(true);
	};
  
	const handleClose = () => {
	  setOpen(false);
	  handleDeleteClick(contact.id)
	};
  

  return (
    <tr>
      <td>{contact.user}</td>
      <td>{contact.role}</td>
     
      <td>

	  <Button variant="outlined" onClick={handleClickOpen}>
        Delete User
      </Button>

	  <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
    
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to DELETE this user?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>No</Button>
          <Button onClick={handleClose} autoFocus >
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      </td>
    </tr>
  );
};

export default ReadOnlyRow;
