import React, { useMemo } from "react";
import {
  useTable,
  useSortBy,
  usePagination,
  useGlobalFilter,
} from "react-table";
import { FaCaretSquareUp, FaCaretSquareDown } from "react-icons/fa";
import "components/tables/table.css";
import { makeStyles, withStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { Button } from "components/button/Button";
import ReactHTMLTableToExcel from "react-html-table-to-excel";
import InputBase from "@material-ui/core/InputBase";
import exportFromJSON from 'export-from-json';
import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";
import { flexbox } from "@mui/system";


const BootstrapInput = withStyles((theme) => ({
  root: {
    "label + &": {
      marginTop: theme.spacing(2)
    }
  },
  input: {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.background.paper,
    //marginLeft:400,
    border: "1px solid #ced4da",
    fontSize: 16,
    padding: "1px 20px 1px 1px",
    transition: theme.transitions.create(["border-color", "box-shadow"]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"'
    ].join(","),
    "&:focus": {
      borderRadius: 4,
      borderColor: "#80bdff",
      boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
      //marginLeft:400,
    }
  }
}))(InputBase);

const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
    marginLeft: 550,
    marginBottom: 32

  },

}));


export const BasicTable = (props) => {
  const columns = useMemo(() => props.columns, []);
  const data = useMemo(() => props.tdata, []);
  const exporttable=useMemo(() => props.tablename, []);
  const excelfilename=useMemo(() => props.filename, []);
  const tableRows=useMemo(() => props.rows, []);
  const time=useMemo(() => props.time, []);
  console.log("filename",excelfilename);
  const classes = useStyles();


  const tableInstance = useTable({
    columns,
    data,
  });

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    prepareRow,
    page,
    canNextPage,
    canPreviousPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    setGlobalFilter,
    state: { pageIndex, pageSize, globalFilter },
  } = useTable(
    { columns, data, initialState: { pageSize: 5 } },
    useGlobalFilter,
    useSortBy,
    usePagination
  );
  const all=rows.length;
  console.log("rows",all);
  
  return (
    <>
  <label className="rowsT" htmlFor="text">
             <p> Rows :{tableRows}  &emsp;   Time:{time} ms</p>
            </label>
     
    <div classname="dropdown">
    <FormControl className={classes.margin}>
    
        <InputLabel id="demo-customized-select-label">Paging</InputLabel>
        <Select
          native
          labelId="demo-customized-select-label"
          id="demo-customized-select"
           input={<BootstrapInput />}
          value={pageSize}
          onChange={e => setPageSize(Number(e.target.value))}
         
        >
          {[5, 10, 25, 50].map((pageSize) => (
            <option key={pageSize} value={pageSize}>
              {pageSize}
            </option>
          ))}
        </Select>
        
      </FormControl>
      </div>
     
      
<div className="exportContianer">
      {/* <div className="exporttoexcel"> */}
         <ReactHTMLTableToExcel 
      sheet="sheet 1"
      buttonText={("Export")}
      table= {exporttable}
      filename={excelfilename}  
      type="button"
      className="btnnew-onhold"
 />     
 {/* </div> */}
 </div>
     
      <div className="container" >
        <table {...getTableProps()}id={exporttable}>
          <thead>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                    {column.render("Header")}
                    <span>
                      {column.isSorted ? (
                        column.isSortedDesc ? (
                          <FaCaretSquareDown />
                        ) : (
                          <FaCaretSquareUp />
                        )
                      ) : (
                        ""
                      )}
                    </span>
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getTableBodyProps()}>
            {page.map((row) => {
              prepareRow(row);

              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) => {
                    return (
                      <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
       
        {pageSize > 1 && (
          <div className="buttons_container">
            <div className="buttons_wrapper">
              <div>
                <span>
                  <Button
                    type="button"
                    className="page1"
                    onClick={() => gotoPage(0)}
                    disabled={!canPreviousPage}
                  >
                    {"<<"}
                  </Button>
                  <Button
                    type="button"
                    className="prevbtn"
                    disabled={!canPreviousPage}
                    onClick={() => previousPage()}
                  >
                    Prev
                  </Button>
                  <Button
                    type="button"
                    className="nextbtn"
                    disabled={!canNextPage}
                    onClick={() => nextPage()}
                  >
                    Next
                  </Button>
                  <Button
                    type="button"
                    className="lastpage"
                    onClick={() => gotoPage(pageCount - 1)}
                    disabled={!canNextPage}
                  >
                    {">>"}
                  </Button>
                </span>
              </div>
            </div>
      <div className="textpagesize">
            <span>
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{' '}
        </span>
        <span>
          | Go to page:{' '}
          <input
            type='number'
            defaultValue={pageIndex + 1}
            onChange={e => {
              const pageNumber = e.target.value ? Number(e.target.value) - 1 : 0
              gotoPage(pageNumber)
            }}
            style={{ width: '50px' }}
          />
        </span>{' '}
        </div>
           
          </div>
        )}
      </div>
    </>
  );
};
