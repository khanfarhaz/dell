import React from "react";

export default function KeyValueTable1(props) {
  const header = props.header;
  const values = Object.values(props.values);
  console.log(values);
  const cssTable = props.cssTable;
  const cssRow = props.cssRow;
  const cssHeader = props.cssHeader;
  const cssAlternateRow = props.cssAlternateRow;
  return (
    <div>
      <table className={cssTable}>
        <tbody>
          <tr className={cssHeader}>
            <th>{header}</th>
          </tr>
          {values.map(({ key, value }) => (
            <tr className={cssRow}>
              <td key={key}>{key}</td>
              <td key={value}>{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
