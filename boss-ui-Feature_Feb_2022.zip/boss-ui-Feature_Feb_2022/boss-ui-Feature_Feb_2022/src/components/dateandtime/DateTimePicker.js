import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";

const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    flexWrap: "wrap",
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 1000,
  },
  labelRoot: {
    fontSize: 18,
    color: "green",
  },
}));

export default function DateTimePicker(props) {
  const name = props.name;
  const disable = props.disabled;
  const classes = useStyles();

  return (
    <form className={classes.container} noValidate>
      <TextField
        id="datetime-local"
        label={name}
        type="datetime-local"
        variant="outlined"
        disabled={disable}
        className={classes.textField}
        onChange={props.onChange}
        value={props.value}
        InputLabelProps={{
          className: classes.labelRoot,
          shrink: true,
        }}
        InputProps={{
          style: {
            height: 39,
            width: 270,
          },
        }}
      />
    </form>
  );
}
