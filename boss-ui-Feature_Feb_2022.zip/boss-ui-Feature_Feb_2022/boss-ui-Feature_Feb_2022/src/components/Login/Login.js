import React from "react";
import { useHistory } from "react-router-dom";

const Login = () => {
  const history = useHistory();
  const fetchUsername = () => {
    if (localStorage.getItem("bossui-user") === null) {
      const queryParams = new URLSearchParams(window.location.search);
      const userName = queryParams.get("user");
      const email = queryParams.get("email");
      localStorage.setItem("bossui-user", userName);
      localStorage.setItem("email", email);
     // console.log("in login");
    }
  };
  const redirectToHome = () => {
    history.push("/");
  };

  return (
    <div>
      {fetchUsername()}
      {redirectToHome()}
    </div>
  );
};

export default Login;
