import React from "react";
import "components/cards/Cards.css";
import CardItem from "components/carditem/CardItem";
import supportImg from "images/image_7.jpg";
import reportsImg from "images/image_8.jpg";
import configAndRulesImg from "images/image_6.png";
import toolsImg from "images/image_5.png";
import admin from "images/admin_woman.jpg";

function Cards() {
  return (
    <div className="cards__wrapper">
      <ul className="cards__items">
        <CardItem src={reportsImg} text="" label="Reports" path="/reports" />
        <CardItem
          src={configAndRulesImg}
          text=""
          label="Configuration"
          path="/configuration"
        
        />
        <CardItem src={supportImg} text="" label="Support" path="/support"  />
        <CardItem src={toolsImg} text="" label="Rules" path="/rules" />
        <CardItem src={admin} text="" label="Admin" path="/Admin" />
      </ul>
    </div>
  );
}

export default Cards;
