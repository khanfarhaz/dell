import React from "react";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  labelRoot: {
    fontSize: 12,
    color: "green",
  },
}));

export default function TextInput(props) {
  const name = props.name;
  const classes = useStyles();
  return (
    <div>
      <TextField
        margin="dense"
        id="outlined-basic"
        label={name}
        variant="outlined"
        onChange={props.onChange}
        value={props.value}
        disabled={props.disabled}
        InputProps={{
          style: {
            height: 39,
            width: 180,
          },
        }}
        InputLabelProps={{
          className: classes.labelRoot,
        }}
      />
    </div>
  );
}
