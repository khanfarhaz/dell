import React from "react";
import { Link, useRouteMatch, NavLink } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import Menu from "@material-ui/core/Menu";
import AccountCircle from "@material-ui/icons/AccountCircle";
import MoreIcon from "@material-ui/icons/MoreVert";
import MenuIcon from "@material-ui/icons/Menu";
import HomeIcon from "@material-ui/icons/Home";
import List from "@material-ui/core/List";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import clsx from "clsx";
import SwipeableDrawer from "@material-ui/core/SwipeableDrawer";
import InboxIcon from "@material-ui/icons/MoveToInbox";
import MailIcon from "@material-ui/icons/Mail";
import logo from "images/dell_technologies_logo.png";
import LabelOutlined from "@material-ui/icons/LabelOutlined";
import IconLibraryBooks from '@material-ui/icons/LibraryBooks'
import Divider from '@material-ui/core/Divider'
import Collapse from '@material-ui/core/Collapse'
import IconExpandLess from '@material-ui/icons/ExpandLess'
import IconExpandMore from '@material-ui/icons/ExpandMore'
import IconBarChart from '@material-ui/icons/BarChart'

const drawerWidth = 290;
const useStyles = makeStyles((theme) => ({
  grow: {
    flexGrow: 1,
  },
  logo: {
    maxWidth: 190,
  },
  title: {
    display: "none",
    [theme.breakpoints.up("sm")]: {
      display: "block",
    },
  },
  region: {
    display: "none",
    [theme.breakpoints.up("sm")]: {
      display: "block",
    },
    paddingTop: "8px",
    textTransform: "uppercase",
  },
  inputRoot: {
    color: "inherit",
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "20ch",
    },
  },
  sectionDesktop: {
    display: "none",
    [theme.breakpoints.up("md")]: {
      display: "flex",
    },
  },
  sectionMobile: {
    display: "flex",
    [theme.breakpoints.up("md")]: {
      display: "none",
    },
  },
  //drawer style
  list: {
    width: 290,
    
  },

  fullList: {
      width: "auto",
      
  },
  appBar: {
    width: "100%",
    zIndex: theme.zIndex.drawer + 1,
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
  
    height: `calc(100% - ${theme.spacing(8)}px)`, // subtract appbar height
    top: theme.spacing(8), // push content down to fix scrollbar position
    position:'relative',
      whiteSpace:'nowrap',
      width: drawerWidth,
      paddingTop:theme.spacing(4),
      paddingBottom: theme.spacing(4),
    //  background: '#535454',
      //color: '#fff',
      color:'#fff',
      background: '#0076ce',
      overflowX: 'hidden',
      "&::-webkit-scrollbar": {
        width: "0.4rem",
      },
      "&::-webkit-scrollbar-track": {
        boxShadow: `inset 0 0 6px rgba(0, 0, 0, 0.3)`,
      },
      "&::-webkit-scrollbar-thumb": {
        backgroundColor: "darkgrey",
        outline: `1px solid slategrey`,
        borderRadius: 8,
      },
  },
  drawerContainer:{
   // paddingTop:theme.spacing(4),
    paddingBottom:theme.spacing(4),
        },
  appMenu:{
    width:'100%',    
  },
  
  menuItem:{
    width:drawerWidth,
  },
  menuItemIcon:{
   // color:'#1589FF'
  // color:'#fff'
  color:'#97c05c'
  },
  subMenuItemIcon:{
    color:'#97c05c'
  },
}));

export default function PrimarySearchAppBar(props) {
  const { path } = useRouteMatch();
  const reqRegion = path.split("/")[1];

  const user = props.user;
  const email = props.email;
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);
  const [state, setState] = React.useState({
    left: false,
  });

  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = (event) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };

  const [openNackOrders,setOpenNackOrders] = React.useState(false)

    function handleClick(){
      setOpenNackOrders(!openNackOrders)
  
    }

    const [open3PL,setOpen3PL] = React.useState(false)

    function handleClick3PL(){
      setOpen3PL(!open3PL)
  
    }

  const menuId = "primary-search-account-menu";
  const renderMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      id={menuId}
      keepMounted
      transformOrigin={{ vertical: "top", horizontal: "right" }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      <MenuItem onClick={handleMenuClose}>{user}</MenuItem>
      <MenuItem onClick={handleMenuClose}>{email}</MenuItem>
    </Menu>
  );

  const mobileMenuId = "primary-search-account-menu-mobile";
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorEl}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{ vertical: "top", horizontal: "right" }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
    >
      <MenuItem onClick={handleProfileMenuOpen}>
        <IconButton
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <AccountCircle />
        </IconButton>
        <p>{user}</p>
      </MenuItem>
    </Menu>
  );
  const toggleDrawer = (anchor, open) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };

  const list = (anchor) => (
    <div
      className={clsx(classes.list, {
        [classes.fullList]: anchor === "top" || anchor === "bottom",
      })}
 //     role="presentation"
 //     onClick={toggleDrawer(anchor, false)}
 //     onKeyDown={toggleDrawer(anchor, false)}
    >
     
      <List component="nav" className={classes.appMenu} disablePadding>
        <ListItem button className={classes.menuItem} component={Link} to="/">
          <ListItemIcon className={classes.menuItemIcon}>
          <HomeIcon />
          </ListItemIcon>
          <ListItemText>Home</ListItemText>
        </ListItem>
        <Divider/> 

        <ListItem button component={Link} to={`/${reqRegion}/reports/onhold`}>
        <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>Onhold</ListItemText>
        </ListItem>
       
        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/asn-summary`}
        >
        <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>Asn Summary</ListItemText>
        </ListItem>
        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/asn-detail`}
        >
         <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>Asn Detail</ListItemText>
        </ListItem>
        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/po-summary`}
        >
          <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>Production Order</ListItemText>
        </ListItem>
        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/po-detail`}
        >
         <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>Production Order Detail</ListItemText>
        </ListItem>
        
        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/vendorworkorder`}
        >
          <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>Vendor Work Order Detail</ListItemText>
        </ListItem>

        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/bulkreportorder`}
        >
          <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>Bulk Report Order</ListItemText>
        </ListItem>

        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/sn-summary`}
        >
         <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon> 
          <ListItemText>Ship Notice Summary</ListItemText>
        </ListItem>

        {/* <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/voidelayhistory`}
        >
          <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon> 
          <ListItemText>VOI Delay History</ListItemText>
        </ListItem> */}

        <ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/sn-hold-log`}
        >
          <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon> 
          <ListItemText>SN Hold Log</ListItemText>
        </ListItem>

        <ListItem button onClick={handleClick} className={classes.menuItem}>
            <ListItemIcon className={classes.menuItemIcon}>
                <IconLibraryBooks/>
                </ListItemIcon>
<ListItemText primary="Nack Orders"/>
{openNackOrders ? <IconExpandLess/>:<IconExpandMore />}
        </ListItem>

    <Divider/>    
    <Collapse in={openNackOrders} timeout="auto" unmountOnExit>
<List component="div" disablePadding>
  
    <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/oppfailedorderdetailsreports`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="OPP Failed Orders" />
        </ListItem>
    
        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/vendorponack`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="Vendor PO NACK" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/preasnnack`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="PREASN NACK" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/asnnack`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="ASN NACK" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/snnack`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="SN NACK" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/systemerror`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="System Error" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/businesserrorpage`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="Business Error" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/spnack`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="SP NACK" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/tcerrordetail`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="TC Error" />
        </ListItem>

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/asbuiltnack`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="AsBuilt NACK" />
        </ListItem>
    
</List>
</Collapse>

<ListItem button onClick={handleClick3PL} className={classes.menuItem}>
            <ListItemIcon className={classes.menuItemIcon}>
                <IconLibraryBooks/>
                </ListItemIcon>
<ListItemText primary="3PL Nack ASNs"/>
{open3PL ? <IconExpandLess/>:<IconExpandMore />}
        </ListItem>

    <Divider/>    
    <Collapse in={open3PL} timeout="auto" unmountOnExit>
<List component="div" disablePadding>
  
    <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/3plinbound`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="3PL Inbound" />
        </ListItem>  

        <ListItem className={classes.menuItem}
          button
          component={Link}
          to={`/${reqRegion}/reports/3ploutbound`}
        >
         <ListItemIcon className={classes.subMenuItemIcon}>
                <IconBarChart/>
                </ListItemIcon> 
          <ListItemText primary="3PL Outbound" />
        </ListItem>  

    
</List>
</Collapse>
     
<ListItem
          button
          component={Link}
          to={`/${reqRegion}/reports/vwostatushistory`}
        >
          <ListItemIcon className={classes.menuItemIcon}>
        <IconLibraryBooks/>
          </ListItemIcon>
          <ListItemText>VWO Status History</ListItemText>
        </ListItem> 
        
      </List>
      
    </div>
  );

  const drawerItems = [
    { text: "TodoList", icon: <ListItemIcon /> },
    { text: "Tags", icon: <ListItemIcon /> },
  ];

  return (
    <div className={classes.grow}>
      <AppBar
        position="fixed"
        style={{ backgroundColor: "#0076ce" }}
        className={classes.appBar}
        classes={{
          paper: classes.drawerPaper,
        }}
      >
        <Toolbar>
          <IconButton
            edge="start"
            className={classes.menuButton}
            color="inherit"
            aria-label="open drawer"
            onClick={toggleDrawer("left", true)}
          >
            <MenuIcon />
          </IconButton>
          <NavLink to="/">
            <img src={logo} alt="logo" className={classes.logo} />
          </NavLink>
          <Typography className={classes.title} variant="h6" noWrap>
            BOSS UI
          </Typography>

          <div className={classes.grow} />
          <div className={classes.sectionDesktop}>
            <Typography className={classes.region} variant="h6" noWrap>
              {reqRegion}
            </Typography>
            <IconButton
              edge="end"
              aria-label="account of current user"
              aria-controls={menuId}
              aria-haspopup="true"
              onClick={handleProfileMenuOpen}
              color="inherit"
            >
              <AccountCircle />
            </IconButton>
          </div>
          <div className={classes.sectionMobile}>
            <IconButton
              aria-label="show more"
              aria-controls={mobileMenuId}
              aria-haspopup="true"
              onClick={handleMobileMenuOpen}
              color="inherit"
            >
              <MoreIcon />
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
      {["left"].map((anchor) => (
        <React.Fragment key={anchor}>
          <SwipeableDrawer
            // className={classes.drawer}
            anchor={anchor}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
            onOpen={toggleDrawer(anchor, true)}
            variant="temporary"
            classes={{
              paper: classes.drawerPaper,
            }}
          >
            <div className={classes.drawerContainer}>{list(anchor)}</div>
          </SwipeableDrawer>
        </React.Fragment>
      ))}

      {renderMobileMenu}
      {renderMenu}
    </div>
  );
}
