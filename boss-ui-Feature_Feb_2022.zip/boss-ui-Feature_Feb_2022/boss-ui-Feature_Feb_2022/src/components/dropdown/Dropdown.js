import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 180,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  root: {
    color: "green",
    fontSize: 12,
  },
}));

export default function Dropdown(props) {
  const textLabel = props.name;
  const labelVal = textLabel;
  const listItems = props.listItems;
  const sendDataToParent = props.sendDataToParent;
  const classes = useStyles();

  const handleChange = (event) => {
    sendDataToParent(textLabel, event.target.value);
  };

  return (
    <div>
      <FormControl
        variant="outlined"
        className={classes.formControl}
        margin="dense"
        disabled={props.disabled}
      >
        <InputLabel
          id="demo-simple-select-outlined-label"
          classes={{ root: classes.root }}
        >
          {labelVal}
        </InputLabel>
        <Select
          labelId="demo-simple-select-outlined-label"
          id="demo-simple-select-outlined"
          onChange={handleChange}
          displayEmpty
          value={props.value}
          label={labelVal}
          InputLabelProps={{
            className: classes.labelRoot,
          }}
        >
          {/* <MenuItem disabled value="">
            <em>ALL</em>
          </MenuItem> */}

          {listItems.map(function (name, index) {
            return <MenuItem value={name}>{name}</MenuItem>;
          })}
        </Select>
      </FormControl>
    </div>
  );
}
//export default Dropdown;
