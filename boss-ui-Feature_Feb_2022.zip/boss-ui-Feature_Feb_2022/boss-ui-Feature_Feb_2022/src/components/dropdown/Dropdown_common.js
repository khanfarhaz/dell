import React from 'react';
import Select from 'react-select';
import  './Dropdown.css';
import { DropdownData } from './DropdownData';
import { Link } from 'react-router-dom';
import './Dropdown.css'

const datadropdown=DropdownData;

const options= datadropdown.map(d=>({
  "value":d.id,
  "label":d.title,
  "Link":d.Link
}))


function Dropdown_common(props){
  const value= props.value
  return(
    <div >
      <div className='dropdown-menu-region'>{props.value}</div>
      <div >
      <Select  options={options} style={{'width':'448px'}}/>
      </div>
      
    </div>
  )
}

export default Dropdown_common