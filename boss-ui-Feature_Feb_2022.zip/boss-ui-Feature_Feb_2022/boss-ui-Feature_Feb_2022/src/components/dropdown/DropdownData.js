import React from 'react'

export const DropdownData=[
    {
        id:1,
        title:'Sales Order Id(s)',
        path:'/DAOregion',
    },
    {
        id:2,
        title:'Production Order Number(s)',
        path:'/EMEAregion',
    },
    {
        id:3,
        title:'Vendor Work Order Id(s)',
        path:'/APJregion',
    },
    {
        id:4,
        title:'Service Tag(s)',
        path:'/APJregion',
    },
    {
        id:5,
        title:'Agreement ID(s)',
        path:'/APJregion',
    }
]