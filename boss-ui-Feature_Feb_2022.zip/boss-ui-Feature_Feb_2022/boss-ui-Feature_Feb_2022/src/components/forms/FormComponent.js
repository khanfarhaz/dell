import { DropDownMenu } from "material-ui";
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./FormComponent.css";
import DropDown from "./Dropdown";
import Search from "./Search";
import Dropdown from "./Dropdown";
import DatePicker from "react-date-picker";
import { Button } from "./Button";
import { DateRangeInput } from "@datepicker-react/styled";
import { ThemeProvider } from "styled-components";
import DateAndTimePickers from "./Datepicker";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import NativeSelect from "@material-ui/core/NativeSelect";
import Dropdown_common from "./Dropdown_common";

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

function FormComponent() {
  const classes = useStyles();
  const [state, setState] = React.useState({
    isChecked: true,
  });

  const handleChange = (event) => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value,
    });
  };

  const [value, onChange] = useState(new Date());
  const [valchecked, setradioinput] = useState(false);
  //const[checkuncheck,toggleChange]= useState();

  const inputchangehandler = () => {
    setradioinput((valchecked) => !valchecked);
    console.log("value", valchecked);
    //valchecked => !valchecked
    //   setradioinput({  valchecked: "true" });
    // console.log("checkbox val",valchecked)
    //console.log("is checked", isChecked)
  };
  // const toggleChange = (event) => {
  //   this.setState({
  //     isChecked: !this.state.isChecked,
  //   });
  // }

  return (
    <>
      <div className="formcards">
        <div className="formcards__container">
          <div className="narrative">On Hold Report</div>

          <form>
            <div className="formcards__wrapper">
              <ul className="formcards__items">
                <div className="component">
                  <label>
                    <input
                      type="text"
                      name=" SalesOrder"
                      placeholder="Sales Order"
                    />
                  </label>
                </div>
                <div className="component">
                  <label>
                    <input
                      type="text"
                      name="Vendor"
                      placeholder="Production Order"
                    />
                  </label>
                </div>
                <div className="component">
                  <label>
                    <input
                      type="text"
                      name=" SalesOrder"
                      placeholder="Company Number"
                    />
                  </label>
                </div>
              </ul>
            </div>
            <div className="formcards__wrapper">
              <ul className="formcards__items">
                <div className="component">
                  <label>
                    <input
                      type="text"
                      name="Vendor"
                      placeholder="Location Number"
                    />
                  </label>
                </div>
                <div className="component">
                  <label>
                    <input
                      type="text"
                      name=" SalesOrder"
                      placeholder="Vendor Work Order"
                    />
                  </label>
                </div>
                <div className="component">
                  <label>
                    <input
                      type="text"
                      name="Region"
                      placeholder="Agreement ID"
                    />
                  </label>
                </div>
              </ul>
            </div>

            <div className="formcards__wrapper">
              <ul className="formcards__items">
                <div className="component">
                  <label>
                    {/* <input type="text" name="Region" placeholder="Demand region"/>
                     */}

                    <Dropdown value={"Region"} />
                  </label>
                </div>
                <div className="component">
                  <label>
                    <Dropdown value={"Vendor"} />
                  </label>
                </div>

                <Dropdown value={"Location no"} />
                <Dropdown value={"Company no"} />
                {/*           
             <label>
             <Button >Query search</Button>
             <Button >Reset Values</Button>
             <Button >Export to excel</Button>
             </label> */}
              </ul>

              {/* <div className='formcards__wrapper'> */}
              <ul className="formcards__items">
                <div className="date-component-onhold">
                  <label>
                    From:
                    <DatePicker
                      onChange={onChange}
                      value={value}
                      disabled={valchecked}
                    />
                  </label>
                  <label>
                    To:
                    <DatePicker
                      onChange={onChange}
                      value={value}
                      disabled={valchecked}
                    />
                  </label>
                  {/* <DateAndTimePickers disabled={radioinput}/> 
          <DateAndTimePickers disabled={radioinput}/>  */}
                  <div>
                    <input
                      type="checkbox"
                      value={valchecked}
                      name="date"
                      /*onChange={this.toggleChange}*/ onChange={
                        inputchangehandler
                      }
                    />{" "}
                    Date
                  </div>
                  <button className="btnnew-onhold">Query Search</button>

                  <button className="btnnew-onhold">Reset Values</button>

                  <button className="btnnew-onhold">Export To Excel</button>
                  <FormControl className={classes.formControl}>
                    <InputLabel htmlFor="age-native-simple">
                      Current Page
                    </InputLabel>
                    <Select
                      native
                      value={state.age}
                      onChange={handleChange}
                      inputProps={{
                        name: "age",
                        id: "age-native-simple",
                      }}
                    >
                      <option aria-label="None" value="" />
                      <option value={10}>Current page</option>
                      <option value={20}>All pages</option>
                    </Select>
                  </FormControl>
                  <div>
                    {" "}
                    <input
                      type="checkbox"
                      value="false"
                      /*onChange={this.toggleChange}*/ name="grid lines"
                    />{" "}
                    Include Grid Lines
                  </div>

                  {/* <label>
            <input type="radio"  checked={true} onChange={inputchangehandler} 
      value = "date" />
            Disable date
          </label> */}

                  {/* <label>
            <input type="radio" value="disable date" checked={true} />
            Include grid lines
          </label> */}
                </div>
              </ul>
            </div>

            {/* </div> */}
          </form>
        </div>
      </div>
    </>
  );
}

export default FormComponent;
